import type {
  DeliveryMode,
  GeneratedFileItem,
  ProjectType,
  TaskState,
  ValidatorResult,
} from './titanTypes.ts';

export const SUPPORTED_LANGUAGES = [
  'Luau',
  'Lua',
  'Python',
  'JavaScript',
  'TypeScript',
  'TSX',
  'JSX',
  'Kotlin',
  'Java',
  'C',
  'C++',
  'C#',
  'Go',
  'Rust',
  'PHP',
  'Ruby',
  'Swift',
  'Dart',
  'R',
  'Perl',
  'Scala',
  'Haskell',
  'Assembly',
  'SQL',
  'HTML',
  'CSS',
  'SCSS',
  'Vue',
  'Svelte',
  'Shell',
  'Bash',
  'PowerShell',
  'JSON',
  'YAML',
  'TOML',
  'XML',
  'Markdown',
  'GraphQL',
  'Protobuf',
] as const;

export interface LanguageDetection {
  language: string;
  environment: string;
  projectType: ProjectType;
  ambiguous: boolean;
  confidence: 'high' | 'medium' | 'low';
}

const SINGLE_FILE_PATTERNS: RegExp[] = [
  /\b(em um [úu]nico (script|arquivo|bloco))\b/i,
  /\b(tudo em um ([úu]nico )?arquivo)\b/i,
  /\b(n[ãa]o divida|sem dividir|sem m[óo]dulos externos)\b/i,
  /\b(arquivo [úu]nico|single[- ]file|one[- ]file|all[- ]in[- ]one)\b/i,
  /\b(quero copiar e executar|copy and run|c[óo]digo completo em um)\b/i,
];

const MULTI_FILE_PATTERNS: RegExp[] = [
  /\b(v[áa]rios arquivos|m[úu]ltiplos arquivos|multi[- ]file|projeto completo|estrutura completa)\b/i,
  /\b(android|apk|kotlin|gradle|fullstack|backend e frontend|api completa)\b/i,
];

export function detectSingleFileIntent(
  prompt: string,
  overrideMode: DeliveryMode = 'auto',
): { singleFile: boolean; reason: string } {
  if (overrideMode === 'single-file') {
    return { singleFile: true, reason: 'Modo Arquivo Único selecionado explicitamente.' };
  }
  if (overrideMode === 'multi-file') {
    return { singleFile: false, reason: 'Modo Múltiplos Arquivos selecionado explicitamente.' };
  }
  for (const pattern of SINGLE_FILE_PATTERNS) {
    const match = prompt.match(pattern);
    if (match) {
      return {
        singleFile: true,
        reason: `Single-File Intelligence ativada pela frase "${match[0]}".`,
      };
    }
  }
  for (const pattern of MULTI_FILE_PATTERNS) {
    const match = prompt.match(pattern);
    if (match) {
      return {
        singleFile: false,
        reason: `Arquitetura multi-arquivo detectada para "${match[0]}".`,
      };
    }
  }
  return {
    singleFile: true,
    reason: 'Script único auto-contido padrão para execução direta.',
  };
}

export function detectLanguageAndEnvironment(
  prompt: string,
  explicitLanguage?: string,
  explicitEnvironment?: string,
): LanguageDetection {
  const lower = prompt.toLowerCase();

  if (explicitLanguage && explicitLanguage !== 'Auto') {
    const env =
      explicitEnvironment && explicitEnvironment !== 'Auto'
        ? explicitEnvironment
        : inferEnvironmentFromLanguage(explicitLanguage, lower);
    return {
      language: explicitLanguage,
      environment: env,
      projectType: inferProjectType(explicitLanguage, env, lower),
      ambiguous: false,
      confidence: 'high',
    };
  }

  const rules: Array<{
    regex: RegExp;
    language: string;
    environment: string;
    projectType: ProjectType;
  }> = [
    { regex: /\b(luau|roblox|localscript|modulescript|remoteevent|datastore|bodyvelocity|linearvelocity)\b/i, language: 'Luau', environment: 'Roblox', projectType: 'luau' },
    { regex: /\b(lua)\b/i, language: 'Lua', environment: 'Lua Runtime', projectType: 'script' },
    { regex: /\b(android|apk|mainactivity|gradle|jetpack compose|xml layout)\b/i, language: 'Kotlin', environment: 'Android', projectType: 'android' },
    { regex: /\b(kotlin)\b/i, language: 'Kotlin', environment: 'JVM / Android', projectType: 'android' },
    { regex: /\b(python|py|flask|fastapi|django|tkinter|pandas)\b/i, language: 'Python', environment: 'Python 3', projectType: 'script' },
    { regex: /\b(typescript|\.tsx?)\b/i, language: 'TypeScript', environment: 'Node.js / Web', projectType: 'script' },
    { regex: /\b(html|css|landing page|p[áa]gina web|site|frontend)\b/i, language: 'HTML', environment: 'Browser Web', projectType: 'web' },
    { regex: /\b(javascript|js|node\.?js|express|react)\b/i, language: 'JavaScript', environment: 'Node.js / Browser', projectType: 'web' },
    { regex: /\b(sql|postgres|sqlite|mysql|select|create table)\b/i, language: 'SQL', environment: 'Relational Database', projectType: 'script' },
    { regex: /\b(java|spring boot|maven)\b/i, language: 'Java', environment: 'JVM', projectType: 'script' },
    { regex: /\b(c\+\+|cpp)\b/i, language: 'C++', environment: 'Native C++', projectType: 'script' },
    { regex: /\b(c#|csharp|dotnet|\.net)\b/i, language: 'C#', environment: '.NET', projectType: 'script' },
    { regex: /\b(\bc\b|gcc|clang|stdio\.h)\b/i, language: 'C', environment: 'Native C', projectType: 'script' },
    { regex: /\b(golang|\bgo\b)\b/i, language: 'Go', environment: 'Go Runtime', projectType: 'api' },
    { regex: /\b(rust|cargo)\b/i, language: 'Rust', environment: 'Rust Cargo', projectType: 'script' },
    { regex: /\b(php|laravel)\b/i, language: 'PHP', environment: 'PHP Server', projectType: 'web' },
    { regex: /\b(ruby|rails)\b/i, language: 'Ruby', environment: 'Ruby Runtime', projectType: 'script' },
    { regex: /\b(swift|swiftui|ios)\b/i, language: 'Swift', environment: 'Apple iOS/macOS', projectType: 'script' },
    { regex: /\b(dart|flutter)\b/i, language: 'Dart', environment: 'Flutter / Dart', projectType: 'script' },
    { regex: /\b(bash|shell|\.sh)\b/i, language: 'Bash', environment: 'Linux Shell', projectType: 'script' },
    { regex: /\b(powershell|\.ps1)\b/i, language: 'PowerShell', environment: 'Windows PowerShell', projectType: 'script' },
    { regex: /\b(graphql|gql)\b/i, language: 'GraphQL', environment: 'GraphQL API', projectType: 'api' },
    { regex: /\b(yaml|yml)\b/i, language: 'YAML', environment: 'Config / CI', projectType: 'script' },
    { regex: /\b(xml)\b/i, language: 'XML', environment: 'Markup / Config', projectType: 'script' },
    { regex: /\b(json)\b/i, language: 'JSON', environment: 'Data Schema', projectType: 'script' },
  ];

  for (const rule of rules) {
    if (rule.regex.test(lower)) {
      return {
        language: rule.language,
        environment: explicitEnvironment && explicitEnvironment !== 'Auto' ? explicitEnvironment : rule.environment,
        projectType: rule.projectType,
        ambiguous: false,
        confidence: 'high',
      };
    }
  }

  return {
    language: 'Python',
    environment: explicitEnvironment && explicitEnvironment !== 'Auto' ? explicitEnvironment : 'Universal Runtime',
    projectType: 'script',
    ambiguous: true,
    confidence: 'low',
  };
}

function inferEnvironmentFromLanguage(language: string, promptLower: string): string {
  switch (language) {
    case 'Luau':
      return 'Roblox';
    case 'Kotlin':
      return promptLower.includes('android') || promptLower.includes('apk') ? 'Android' : 'Android / JVM';
    case 'Python':
      return 'Python 3';
    case 'HTML':
    case 'CSS':
      return 'Browser Web';
    case 'TypeScript':
    case 'JavaScript':
      return promptLower.includes('browser') || promptLower.includes('dom') || promptLower.includes('web')
        ? 'Browser Web'
        : 'Node.js';
    case 'SQL':
      return 'SQLite / SQL';
    default:
      return `${language} Runtime`;
  }
}

function inferProjectType(language: string, env: string, promptLower: string): ProjectType {
  if (language === 'Luau') return 'luau';
  if (env === 'Android' || promptLower.includes('apk') || promptLower.includes('android')) return 'android';
  if (language === 'HTML' || env === 'Browser Web') return 'web';
  if (promptLower.includes('api') || promptLower.includes('rest')) return 'api';
  if (promptLower.includes('fullstack')) return 'fullstack';
  return 'script';
}

const BANNED_STUB_PATTERNS: Array<{ regex: RegExp; reason: string }> = [
  { regex: /\bExecutionPayload\b/, reason: 'Detectada estrutura substituta proibida "ExecutionPayload".' },
  { regex: /\bfunction\s+runTask\s*\(/, reason: 'Detectada função substituta genérica "runTask()".' },
  { regex: /Processado:\s*\$\{input/, reason: 'Detectado placeholder genérico de processamento de texto.' },
  { regex: /\bTODO:\s*implement/i, reason: 'Detectado marcador TODO não implementado.' },
  { regex: /\bFIXME\b/i, reason: 'Detectado marcador FIXME pendente.' },
  { regex: /\/\/\s*\.\.\.\s*rest of/i, reason: 'Detectada omissão de código ("...rest of").' },
  { regex: /#\s*\.\.\.\s*rest of/i, reason: 'Detectada omissão de código ("...rest of").' },
  { regex: /--\s*\.\.\.\s*rest of/i, reason: 'Detectada omissão de código ("...rest of").' },
  { regex: /pass\s*#\s*placeholder/i, reason: 'Detectado placeholder Python "pass".' },
];

export function validateLanguageMatch(
  expectedLanguage: string,
  expectedEnvironment: string,
  files: GeneratedFileItem[],
): ValidatorResult {
  if (files.length === 0) {
    return {
      name: 'LanguageMatchValidator',
      executed: true,
      passed: false,
      severity: 'error',
      message: 'Nenhum arquivo gerado para validar linguagem.',
    };
  }

  const combined = files.map((f) => f.content).join('\n');
  const norm = expectedLanguage.toLowerCase();
  const details: string[] = [];

  if (norm === 'luau' || norm === 'lua') {
    const hasTsLeak =
      /\bexport\s+(interface|type|function|const)\b/.test(combined) ||
      /\bimport\s+.*\s+from\s+['"]/.test(combined) ||
      /\bconsole\.log\s*\(/.test(combined);
    const hasLuauTokens =
      /\blocal\s+[a-zA-Z_]/.test(combined) ||
      /\bfunction\b/.test(combined) ||
      /\bend\b/.test(combined);

    if (hasTsLeak) {
      details.push('Código contém sintaxe TypeScript/JavaScript em vez de Luau.');
    }
    if (!hasLuauTokens) {
      details.push('Código não apresenta construtos válidos de Luau/Lua (local, function, end).');
    }
    if (expectedEnvironment.toLowerCase().includes('roblox')) {
      const hasRobloxApi = /game:GetService|script\.Parent|Instance\.new|workspace|Players|RunService|UserInputService|ReplicatedStorage/i.test(
        combined,
      );
      if (!hasRobloxApi) {
        details.push('Ambiente Roblox especificado, mas nenhuma API Roblox padrão foi encontrada.');
      }
    }
  } else if (norm === 'python') {
    const hasJsLeak = /\bexport\s+(interface|function|const)\b/.test(combined) || /\bconsole\.log\s*\(/.test(combined);
    const hasPyTokens = /\bdef\s+\w+\s*\(|\bimport\s+\w+|\bclass\s+\w+|\bprint\s*\(/.test(combined);
    if (hasJsLeak) details.push('Detectado código JavaScript/TypeScript em solicitação Python.');
    if (!hasPyTokens) details.push('Não foram detectadas definições ou instruções Python válidas.');
  } else if (norm === 'kotlin') {
    const hasKotlin = /\b(package|fun|class|val|var|import)\b/.test(combined);
    if (!hasKotlin) details.push('Código Kotlin não contém declarações package/fun/class/val válidas.');
  } else if (norm === 'html') {
    const hasHtml = /<!doctype html|<html|<body|<div|<main|<section/i.test(combined);
    if (!hasHtml) details.push('Projeto Web HTML não contém estrutura HTML válida.');
  } else if (norm === 'javascript' || norm === 'typescript') {
    const hasPyLeak = /^\s*def\s+\w+\s*\(.*\):/m.test(combined);
    if (hasPyLeak) details.push('Detectada sintaxe Python em saída JavaScript/TypeScript.');
  }

  return {
    name: 'LanguageMatchValidator',
    executed: true,
    passed: details.length === 0,
    severity: details.length === 0 ? 'pass' : 'error',
    message:
      details.length === 0
        ? `Linguagem validada: ${expectedLanguage} (${expectedEnvironment}).`
        : `Falha de correspondência para ${expectedLanguage}.`,
    details,
  };
}

export function validateRequirementMatch(
  prompt: string,
  files: GeneratedFileItem[],
): ValidatorResult {
  const lower = prompt.toLowerCase();
  const combined = files.map((f) => f.content).join('\n');
  const details: string[] = [];

  if (/\bfly\b|\bvoo\b|\bvoar\b/i.test(lower)) {
    const hasFlightMechanics =
      /LinearVelocity|BodyVelocity|BodyGyro|AlignOrientation|VectorForce|Humanoid|AssemblyLinearVelocity|Camera\.CFrame/i.test(
        combined,
      );
    const hasInputOrLoop = /UserInputService|RunService|RenderStepped|Heartbeat|ContextActionService/i.test(combined);
    if (!hasFlightMechanics) {
      details.push('Script de voo não implementa física/velocidade real de movimento (ex: LinearVelocity/BodyVelocity/AssemblyLinearVelocity).');
    }
    if (!hasInputOrLoop) {
      details.push('Script de voo não conecta controles de entrada ou loop de atualização (UserInputService/RunService).');
    }
  }

  if (/\bcalculadora\b|\bcalculator\b/i.test(lower)) {
    const hasOps = /(\+|\-|\*|\/)/.test(combined) && /(def|function|match|if|elif|switch|add|subtract|multiply|divide|soma|divis)/i.test(combined);
    const hasErrorHandling = /(ZeroDivisionError|try|except|catch|throw|ValueError|NaN|isFinite)/i.test(combined);
    if (!hasOps) details.push('Calculadora não implementa operações matemáticas reais.');
    if (!hasErrorHandling) details.push('Calculadora não trata erros como divisão por zero ou entrada inválida.');
  }

  if (/\bandroid\b|\bapk\b/i.test(lower)) {
    const hasMainActivity = files.some((f) => f.path.endsWith('MainActivity.kt') || f.path.endsWith('MainActivity.java'));
    if (!hasMainActivity) {
      details.push('Projeto Android não possui MainActivity implementada.');
    }
  }

  return {
    name: 'RequirementMatchValidator',
    executed: true,
    passed: details.length === 0,
    severity: details.length === 0 ? 'pass' : 'error',
    message:
      details.length === 0
        ? 'Implementação atende aos requisitos funcionais identificados.'
        : 'Requisitos funcionais incompletos no código gerado.',
    details,
  };
}

export function validateCodeCompleteness(files: GeneratedFileItem[]): ValidatorResult {
  const details: string[] = [];

  for (const file of files) {
    const trimmed = file.content.trim();
    if (trimmed.length < 25) {
      details.push(`Arquivo "${file.path}" está vazio ou excessivamente curto (${trimmed.length} caracteres).`);
    }
    for (const banned of BANNED_STUB_PATTERNS) {
      if (banned.regex.test(file.content)) {
        details.push(`[${file.path}] ${banned.reason}`);
      }
    }
    if (/fun\s+onCreate\s*\([^)]*\)\s*\{\s*(super\.onCreate\([^)]*\)\s*)?\}/s.test(file.content)) {
      details.push(`[${file.path}] MainActivity.onCreate() está vazia (sem interface ou comportamento real).`);
    }
  }

  return {
    name: 'CodeCompletenessValidator',
    executed: true,
    passed: details.length === 0,
    severity: details.length === 0 ? 'pass' : 'error',
    message:
      details.length === 0
        ? 'Nenhuma função vazia, stub genérico ou placeholder detectado.'
        : 'Detectados stubs, omissões ou funções vazias.',
    details,
  };
}

export function validateSingleFile(
  singleFileRequired: boolean,
  files: GeneratedFileItem[],
): ValidatorResult {
  if (!singleFileRequired) {
    return {
      name: 'SingleFileValidator',
      executed: true,
      passed: true,
      severity: 'pass',
      message: 'Modo multi-arquivo ativo; consolidação em arquivo único não exigida.',
    };
  }

  const details: string[] = [];
  if (files.length !== 1) {
    details.push(`Single-File Mode exigia exatamente 1 arquivo, mas foram gerados ${files.length}.`);
  }

  const file = files[0];
  if (file) {
    if (/require\s*\(\s*script\.Parent|from\s+['"]\.\.?\/|import\s+['"]\.\.?\//.test(file.content)) {
      details.push('Código em arquivo único referencia módulos externos locais (./, ../ ou script.Parent).');
    }
    if (file.content.trim().length < 60) {
      details.push('Arquivo único não possui implementação substancial completa.');
    }
  }

  return {
    name: 'SingleFileValidator',
    executed: true,
    passed: details.length === 0,
    severity: details.length === 0 ? 'pass' : 'error',
    message:
      details.length === 0
        ? 'Código consolidado em um único arquivo auto-contido sem dependências internas quebradas.'
        : 'Violação de integridade do Single-File Mode.',
    details,
  };
}

export function validateProjectCompleteness(
  projectType: ProjectType,
  singleFileRequired: boolean,
  prompt: string,
  files: GeneratedFileItem[],
): ValidatorResult {
  if (singleFileRequired) {
    return {
      name: 'ProjectCompletenessValidator',
      executed: true,
      passed: true,
      severity: 'pass',
      message: 'Projeto validado em modo arquivo único.',
    };
  }

  const details: string[] = [];
  const paths = files.map((f) => f.path.toLowerCase());

  if (projectType === 'android') {
    const requiredChecks = [
      { check: paths.some((p) => p.endsWith('androidmanifest.xml')), label: 'AndroidManifest.xml' },
      { check: paths.some((p) => p.endsWith('build.gradle.kts') || p.endsWith('build.gradle')), label: 'build.gradle.kts' },
      { check: paths.some((p) => p.endsWith('mainactivity.kt') || p.endsWith('mainactivity.java')), label: 'MainActivity.kt' },
      { check: paths.some((p) => p.endsWith('strings.xml') || p.endsWith('.xml')), label: 'Recursos XML (strings.xml / layout)' },
      { check: paths.some((p) => p.endsWith('readme.md')), label: 'README.md' },
    ];
    for (const req of requiredChecks) {
      if (!req.check) details.push(`Arquivo essencial Android ausente: ${req.label}.`);
    }

    const mainAct = files.find((f) => f.path.toLowerCase().endsWith('mainactivity.kt'));
    if (mainAct && !/setContent|setContentView|ComponentActivity|AppCompatActivity/.test(mainAct.content)) {
      details.push('MainActivity.kt não inicializa interface real (setContent / setContentView).');
    }
  }

  if (projectType === 'web') {
    const hasHtml = paths.some((p) => p.endsWith('.html'));
    if (!hasHtml) details.push('Projeto Web não possui arquivo .html.');
  }

  const readme = files.find((f) => f.path.toLowerCase().endsWith('readme.md'));
  if (readme && prompt.trim().length > 20 && readme.content.trim() === prompt.trim()) {
    details.push('README.md apenas repete o prompt original sem documentação real.');
  }

  return {
    name: 'ProjectCompletenessValidator',
    executed: true,
    passed: details.length === 0,
    severity: details.length === 0 ? 'pass' : 'error',
    message:
      details.length === 0
        ? `Estrutura completa verificada (${files.length} arquivos implementados).`
        : 'Projeto multi-arquivo incompleto.',
    details,
  };
}

export function validateDependencies(files: GeneratedFileItem[]): ValidatorResult {
  const details: string[] = [];
  const filePaths = new Set(files.map((f) => f.path.replace(/^\.\//, '')));

  for (const file of files) {
    const relImports = [...file.content.matchAll(/from\s+['"](\.[^'"]+)['"]/g)];
    for (const match of relImports) {
      const imp = match[1];
      const baseDir = file.path.includes('/') ? file.path.slice(0, file.path.lastIndexOf('/')) : '';
      const resolved = normalizeRelativePath(baseDir, imp);
      const candidates = [
        resolved,
        `${resolved}.ts`,
        `${resolved}.tsx`,
        `${resolved}.js`,
        `${resolved}.jsx`,
        `${resolved}/index.ts`,
        `${resolved}/index.js`,
      ];
      if (!candidates.some((c) => filePaths.has(c))) {
        details.push(`[${file.path}] Import relativo aponta para arquivo inexistente: "${imp}".`);
      }
    }
  }

  return {
    name: 'DependencyValidator',
    executed: true,
    passed: details.length === 0,
    severity: details.length === 0 ? 'pass' : 'error',
    message:
      details.length === 0
        ? 'Dependências e referências internas consistentes.'
        : 'Referências ou dependências quebradas detectadas.',
    details,
  };
}

function normalizeRelativePath(baseDir: string, rel: string): string {
  const parts = baseDir ? baseDir.split('/') : [];
  for (const seg of rel.split('/')) {
    if (seg === '.' || seg === '') continue;
    if (seg === '..') parts.pop();
    else parts.push(seg);
  }
  return parts.join('/');
}

export function validateSyntaxStatic(files: GeneratedFileItem[]): ValidatorResult {
  const details: string[] = [];

  for (const file of files) {
    const ext = file.path.split('.').pop()?.toLowerCase() ?? '';
    const lang = file.language.toLowerCase();

    if (lang === 'json' || ext === 'json') {
      try {
        JSON.parse(file.content);
      } catch (err) {
        details.push(`[${file.path}] JSON inválido: ${err instanceof Error ? err.message : String(err)}`);
      }
    }

    if (lang === 'luau' || lang === 'lua' || ext === 'luau' || ext === 'lua') {
      const cleaned = file.content
        .replace(/--\[\[[\s\S]*?\]\]/g, '')
        .replace(/--.*$/gm, '')
        .replace(/"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\[\[[\s\S]*?\]\]/g, '""');
      const openers = (cleaned.match(/\b(function|if|for|while|repeat)\b/g) || []).length;
      const closers = (cleaned.match(/\b(end|until)\b/g) || []).length;
      if (Math.abs(openers - closers) > 1) {
        details.push(`[${file.path}] Possível desbalanceamento de blocos Luau (aberturas: ${openers}, fechamentos: ${closers}).`);
      }
    }

    // Balanced braces/parens check for brace languages
    if (['javascript', 'typescript', 'kotlin', 'java', 'c', 'c++', 'c#', 'go', 'rust', 'css'].includes(lang)) {
      const braceError = checkBalancedDelimiters(file.content);
      if (braceError) {
        details.push(`[${file.path}] ${braceError}`);
      }
    }

    if (lang === 'xml' || ext === 'xml') {
      const openTags = (file.content.match(/<([a-zA-Z0-9_:-]+)(?=[\s>])(?![^>]*\/>)/g) || []).length;
      const closeTags = (file.content.match(/<\/([a-zA-Z0-9_:-]+)>/g) || []).length;
      if (openTags !== closeTags) {
        details.push(`[${file.path}] Tags XML desbalanceadas (abertas: ${openTags}, fechadas: ${closeTags}).`);
      }
    }
  }

  return {
    name: 'SyntaxValidator',
    executed: true,
    passed: details.length === 0,
    severity: details.length === 0 ? 'pass' : 'error',
    message:
      details.length === 0
        ? 'Verificação sintática estática aprovada.'
        : 'Erros sintáticos ou estruturais detectados.',
    details,
  };
}

function checkBalancedDelimiters(code: string): string | null {
  const stripped = code
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/\/\/.*$/gm, '')
    .replace(/`(?:\\.|[^`\\])*`|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/g, '""');
  let curly = 0;
  let paren = 0;
  let bracket = 0;
  for (const ch of stripped) {
    if (ch === '{') curly++;
    else if (ch === '}') curly--;
    else if (ch === '(') paren++;
    else if (ch === ')') paren--;
    else if (ch === '[') bracket++;
    else if (ch === ']') bracket--;
    if (curly < 0 || paren < 0 || bracket < 0) {
      return 'Delimitador de fechamento inesperado ({, (, [).';
    }
  }
  if (curly !== 0 || paren !== 0 || bracket !== 0) {
    return `Delimitadores desbalanceados (chaves: ${curly}, parênteses: ${paren}, colchetes: ${bracket}).`;
  }
  return null;
}

export function computeFinalDelivery(
  validators: ValidatorResult[],
): { status: TaskState; summaryValidator: ValidatorResult } {
  const hardFailures = validators.filter((v) => !v.passed && v.severity === 'error');
  const blocked = validators.filter((v) => v.severity === 'blocked');

  if (hardFailures.length > 0) {
    const summaryValidator: ValidatorResult = {
      name: 'FinalDeliveryValidator',
      executed: true,
      passed: false,
      severity: 'error',
      message: `${hardFailures.length} validador(es) reprovado(s). Correção necessária antes da entrega.`,
      details: hardFailures.map((f) => `${f.name}: ${f.message}`),
    };
    return { status: 'NEEDS_CORRECTION', summaryValidator };
  }

  if (blocked.length > 0) {
    const summaryValidator: ValidatorResult = {
      name: 'FinalDeliveryValidator',
      executed: true,
      passed: true,
      severity: 'warning',
      message: 'Código validado estaticamente, com etapas de compilação/runtime externo sinalizadas como pendentes de infraestrutura.',
      details: blocked.map((b) => `${b.name}: ${b.message}`),
    };
    return { status: 'COMPLETED', summaryValidator };
  }

  return {
    status: 'COMPLETED',
    summaryValidator: {
      name: 'FinalDeliveryValidator',
      executed: true,
      passed: true,
      severity: 'pass',
      message: 'Todos os validadores aplicáveis aprovados com evidência verificável.',
    },
  };
}
