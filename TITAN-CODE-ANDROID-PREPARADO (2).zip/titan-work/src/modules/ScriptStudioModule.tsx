import { Loader2, Play, Sparkles } from 'lucide-react';
import React, { useMemo, useState } from 'react';
import { PipelineResultPanel } from '../components/PipelineResultPanel.tsx';
import { useTitan } from '../contexts/TitanContext.tsx';
import { generateWithPipeline } from '../lib/titanApi.ts';
import { recordTaskExecution, writeAuditLog } from '../lib/workspaceService.ts';
import type { DeliveryMode, GenerationResult } from '../shared/titanTypes.ts';
import {
  SUPPORTED_LANGUAGES,
  detectLanguageAndEnvironment,
  detectSingleFileIntent,
} from '../shared/titanValidators.ts';

const PRESET_PROMPTS = [
  {
    label: 'Fly em Luau (Roblox)',
    prompt: 'Crie um script Fly completo em Luau para Roblox em um único script com ativação por tecla F, controle WASD, Subir/Descer e ajuste de velocidade.',
    lang: 'Auto',
    mode: 'auto' as DeliveryMode,
  },
  {
    label: 'Calculadora Python',
    prompt: 'Crie uma calculadora funcional em Python em um único arquivo com operações soma, subtração, multiplicação, divisão, potência, tratamento de ZeroDivisionError e testes automatizados com assert.',
    lang: 'Auto',
    mode: 'single-file' as DeliveryMode,
  },
  {
    label: 'Gerenciador CLI JS',
    prompt: 'Crie um gerenciador de tarefas CLI em JavaScript em um único arquivo completo que demonstre criação, conclusão, listagem e filtragem no console.',
    lang: 'Auto',
    mode: 'single-file' as DeliveryMode,
  },
  {
    label: 'API FastAPI Python',
    prompt: 'Crie uma API REST em Python usando FastAPI com validação Pydantic, endpoints CRUD de itens e tratamento de erros HTTP.',
    lang: 'Python',
    mode: 'single-file' as DeliveryMode,
  },
];

export function ScriptStudioModule() {
  const { user, userProfile, notify } = useTitan();
  const [prompt, setPrompt] = useState('');
  const [explicitLanguage, setExplicitLanguage] = useState('Auto');
  const [explicitEnvironment, setExplicitEnvironment] = useState('Auto');
  const [deliveryMode, setDeliveryMode] = useState<DeliveryMode>(
    userProfile?.defaultDeliveryMode || 'auto',
  );
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<GenerationResult | null>(null);

  const liveDetection = useMemo(() => {
    if (!prompt.trim()) return null;
    const lang = detectLanguageAndEnvironment(prompt, explicitLanguage, explicitEnvironment);
    const single = detectSingleFileIntent(prompt, deliveryMode);
    return { lang, single };
  }, [prompt, explicitLanguage, explicitEnvironment, deliveryMode]);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) {
      notify('warning', 'Prompt vazio', 'Descreva o script que deseja construir.');
      return;
    }

    setLoading(true);
    try {
      const res = await generateWithPipeline({
        module: 'script-studio',
        prompt,
        explicitLanguage,
        explicitEnvironment,
        deliveryMode,
      });
      setResult(res);

      if (user) {
        await recordTaskExecution({
          ownerId: user.uid,
          module: 'script-studio',
          prompt,
          language: res.plan.language,
          environment: res.plan.environment,
          status: res.status,
          validationSummary: res.validators.map((v) => `${v.name}: ${v.passed ? 'OK' : 'FAIL'}`).join(' | '),
        });
        await writeAuditLog({
          actorId: user.uid,
          module: 'script-studio',
          action: 'generate_script',
          severity: res.status === 'COMPLETED' ? 'info' : 'warning',
          detail: `Script ${res.plan.language} (${res.plan.environment}) finalizado com estado ${res.status}.`,
        });
      }

      if (res.status === 'COMPLETED') {
        notify('success', 'Script Validado', `Código gerado em ${res.plan.language} e aprovado pelos validadores.`);
      } else {
        notify('warning', `Estado: ${res.status}`, res.explanation);
      }
    } catch (err) {
      notify('error', 'Erro na geração', err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-[#0C0C10] border border-zinc-800 rounded-xl p-6 space-y-5">
        <div className="space-y-1">
          <h2 className="font-display text-xl font-bold text-white">
            TITAN Script Studio
          </h2>
          <p className="text-sm text-zinc-400">
            Motor de engenharia com detecção automática de linguagem, Single-File Intelligence, 10 validadores independentes e autocorreção antes da entrega.
          </p>
        </div>

        {/* Presets */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-zinc-500 mr-1">Exemplos rápidos:</span>
          {PRESET_PROMPTS.map((p) => (
            <button
              key={p.label}
              type="button"
              onClick={() => {
                setPrompt(p.prompt);
                setExplicitLanguage(p.lang);
                setDeliveryMode(p.mode);
              }}
              className="px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-xs text-zinc-300 rounded-md transition-colors cursor-pointer"
            >
              {p.label}
            </button>
          ))}
        </div>

        <form onSubmit={handleGenerate} className="space-y-4">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={4}
            placeholder="Ex: Crie um script Fly em Luau para Roblox em um único script completo..."
            className="w-full px-4 py-3 bg-[#070709] border border-zinc-800 focus:border-red-600 rounded-lg text-sm text-zinc-100 placeholder:text-zinc-600 focus:outline-none"
          />

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-zinc-400">
                Linguagem
              </label>
              <select
                value={explicitLanguage}
                onChange={(e) => setExplicitLanguage(e.target.value)}
                className="w-full px-3 py-2 bg-[#070709] border border-zinc-800 rounded-lg text-sm text-zinc-200 focus:outline-none focus:border-red-600"
              >
                <option value="Auto">Reconhecimento Automático</option>
                {SUPPORTED_LANGUAGES.map((lang) => (
                  <option key={lang} value={lang}>
                    {lang}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-zinc-400">
                Ambiente de Execução
              </label>
              <select
                value={explicitEnvironment}
                onChange={(e) => setExplicitEnvironment(e.target.value)}
                className="w-full px-3 py-2 bg-[#070709] border border-zinc-800 rounded-lg text-sm text-zinc-200 focus:outline-none focus:border-red-600"
              >
                <option value="Auto">Automático pelo Contexto</option>
                <option value="Roblox">Roblox Studio</option>
                <option value="Python 3">Python 3</option>
                <option value="Node.js">Node.js</option>
                <option value="Browser Web">Browser Web</option>
                <option value="Android">Android</option>
                <option value="Linux Shell">Linux Shell</option>
                <option value="Relational Database">SQL Database</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-zinc-400">
                Modo de Entrega
              </label>
              <select
                value={deliveryMode}
                onChange={(e) => setDeliveryMode(e.target.value as DeliveryMode)}
                className="w-full px-3 py-2 bg-[#070709] border border-zinc-800 rounded-lg text-sm text-zinc-200 focus:outline-none focus:border-red-600"
              >
                <option value="auto">Automático (Single-File Intelligence)</option>
                <option value="single-file">Arquivo Único Obrigatório</option>
                <option value="multi-file">Múltiplos Arquivos</option>
              </select>
            </div>
          </div>

          {liveDetection && (
            <div className="flex flex-wrap items-center gap-3 text-xs text-zinc-400 pt-1">
              <span>
                Interpretação prévia: <strong className="text-zinc-200">{liveDetection.lang.language}</strong>
              </span>
              <span aria-hidden="true">·</span>
              <span>
                Ambiente: <strong className="text-zinc-200">{liveDetection.lang.environment}</strong>
              </span>
              <span aria-hidden="true">·</span>
              <span>{liveDetection.single.reason}</span>
            </div>
          )}

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2.5 bg-red-600 hover:bg-red-500 disabled:opacity-60 text-white text-sm font-medium rounded-lg inline-flex items-center gap-2 transition-colors cursor-pointer"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Planejando, Gerando e Validando...</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  <span>Construir e Validar Script</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {result ? (
        <PipelineResultPanel result={result} />
      ) : (
        <div className="bg-[#0C0C10] border border-zinc-800 rounded-xl p-10 text-center space-y-2">
          <Sparkles className="w-6 h-6 text-zinc-600 mx-auto" />
          <p className="text-sm text-zinc-300 font-medium">
            Pronto para gerar código-fonte completo
          </p>
          <p className="text-xs text-zinc-500 max-w-md mx-auto">
            Escolha um exemplo rápido ou descreva o script desejado. Todos os resultados passam pelos validadores de linguagem, completude e sintaxe antes da entrega.
          </p>
        </div>
      )}
    </div>
  );
}
