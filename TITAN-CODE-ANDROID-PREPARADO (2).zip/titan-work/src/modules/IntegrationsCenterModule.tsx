import { CheckCircle2, Cpu, KeyRound, PlugZap, RefreshCw, ServerCrash } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { useTitan } from '../contexts/TitanContext.tsx';
import {
  configureAiProvider,
  fetchAiProviders,
  fetchIntegrationsStatus,
  saveVaultSecret,
  testAiProvider,
  testDeployProvider,
} from '../lib/titanApi.ts';
import type {
  AiProviderConfigSummary,
  AiRequestHistoryEntry,
  DeployProviderId,
} from '../shared/titanTypes.ts';

const HOSTING_SLOTS: Array<{ id: DeployProviderId; label: string; hint: string }> = [
  { id: 'render', label: 'Render API Key', hint: 'rnd_...' },
  { id: 'vercel', label: 'Vercel Token', hint: 'Token pessoal ou team' },
  { id: 'netlify', label: 'Netlify Personal Token', hint: 'nfp_...' },
  { id: 'railway', label: 'Railway API Token', hint: 'Token GraphQL Railway' },
  { id: 'cloudflare', label: 'Cloudflare API Token', hint: 'Pages / Workers' },
];

export function IntegrationsCenterModule() {
  const { notify } = useTitan();
  const [providers, setProviders] = useState<AiProviderConfigSummary[]>([]);
  const [history, setHistory] = useState<AiRequestHistoryEntry[]>([]);
  const [vaultStatus, setVaultStatus] = useState<Array<{ slot: string; source: string; configured: boolean }>>([]);
  const [keyDrafts, setKeyDrafts] = useState<Record<string, string>>({});
  const [modelDrafts, setModelDrafts] = useState<Record<string, string>>({});
  const [urlDrafts, setUrlDrafts] = useState<Record<string, string>>({});
  const [busyId, setBusyId] = useState<string | null>(null);

  const loadAll = useCallback(async () => {
    try {
      const [pRes, iRes] = await Promise.all([fetchAiProviders(), fetchIntegrationsStatus()]);
      setProviders(pRes.providers);
      setHistory(pRes.history);
      setVaultStatus(iRes.vault);

      const mMap: Record<string, string> = {};
      const uMap: Record<string, string> = {};
      for (const p of pRes.providers) {
        mMap[p.id] = p.model;
        if (p.baseUrl) uMap[p.id] = p.baseUrl;
      }
      setModelDrafts(mMap);
      setUrlDrafts(uMap);
    } catch (err) {
      notify('error', 'Erro ao carregar integrações', err instanceof Error ? err.message : String(err));
    }
  }, [notify]);

  useEffect(() => {
    void loadAll();
  }, [loadAll]);

  const handleSaveProvider = async (p: AiProviderConfigSummary, enabledOverride?: boolean) => {
    setBusyId(p.id);
    try {
      await configureAiProvider({
        id: p.id,
        model: modelDrafts[p.id] || p.model,
        baseUrl: urlDrafts[p.id],
        enabled: enabledOverride !== undefined ? enabledOverride : p.enabled,
        apiKey: keyDrafts[p.id] !== undefined && p.id !== 'gemini' ? keyDrafts[p.id] : undefined,
      });
      setKeyDrafts((prev) => ({ ...prev, [p.id]: '' }));
      notify('success', `${p.name} atualizado`, 'Configuração salva com segurança no cofre do servidor.');
      await loadAll();
    } catch (err) {
      notify('error', 'Erro ao salvar provedor', err instanceof Error ? err.message : String(err));
    } finally {
      setBusyId(null);
    }
  };

  const handleTestProvider = async (id: string) => {
    setBusyId(id);
    try {
      const res = await testAiProvider(id);
      notify(res.ok ? 'success' : 'warning', `Teste ${id} (${res.status})`, res.detail);
      await loadAll();
    } catch (err) {
      notify('error', 'Falha no teste', err instanceof Error ? err.message : String(err));
    } finally {
      setBusyId(null);
    }
  };

  const handleSaveVaultToken = async (slot: string) => {
    setBusyId(slot);
    try {
      await saveVaultSecret(slot, keyDrafts[slot] || '');
      setKeyDrafts((prev) => ({ ...prev, [slot]: '' }));
      notify('success', `Cofre atualizado (${slot})`, 'Credencial cifrada com AES-256-GCM no servidor.');
      await loadAll();
    } catch (err) {
      notify('error', 'Erro ao gravar token', err instanceof Error ? err.message : String(err));
    } finally {
      setBusyId(null);
    }
  };

  const handleTestHosting = async (provider: DeployProviderId) => {
    setBusyId(provider);
    try {
      const res = await testDeployProvider(provider);
      notify(res.status === 'CONNECTED' ? 'success' : 'warning', `${provider}: ${res.status}`, res.detail);
    } catch (err) {
      notify('error', 'Erro ao testar provedor', err instanceof Error ? err.message : String(err));
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-white tracking-tight">
            TITAN Integrations & Multi-AI Center
          </h1>
          <p className="text-sm text-zinc-400">
            Provedores de IA com fallback automático, Ollama local, tokens de hospedagem e GitHub armazenados no cofre cifrado AES-256-GCM do servidor.
          </p>
        </div>

        <button
          type="button"
          onClick={() => void loadAll()}
          className="px-3 py-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-200 text-xs font-medium rounded-lg flex items-center gap-1.5 cursor-pointer"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Atualizar Status</span>
        </button>
      </div>

      {/* Multi-AI Providers */}
      <div className="bg-[#0E0E13] border border-zinc-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center gap-2 text-sm font-semibold text-white">
          <Cpu className="w-4 h-4 text-red-500" />
          <span>Provedores de Inteligência Artificial & Fallback</span>
        </div>

        <div className="space-y-3">
          {providers.map((p) => (
            <div key={p.id} className="p-4 rounded-xl bg-[#09090D] border border-zinc-800 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  {p.status === 'CONNECTED' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <ServerCrash className="w-4 h-4 text-amber-400 shrink-0" />
                  )}
                  <div>
                    <div className="text-xs font-semibold text-white">{p.name}</div>
                    <div className="text-[11px] font-mono text-zinc-500">
                      Prioridade #{p.priority} · {p.status} · Req: {p.requestCount} · ~{p.estimatedTokens} tokens
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => void handleSaveProvider(p, !p.enabled)}
                    disabled={busyId === p.id}
                    className={`px-2.5 py-1 rounded text-xs font-mono cursor-pointer ${
                      p.enabled
                        ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/50'
                        : 'bg-zinc-900 text-zinc-500 border border-zinc-800'
                    }`}
                  >
                    {p.enabled ? 'HABILITADO' : 'DESATIVADO'}
                  </button>
                  <button
                    type="button"
                    onClick={() => void handleTestProvider(p.id)}
                    disabled={busyId === p.id}
                    className="px-3 py-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-xs text-zinc-200 rounded cursor-pointer"
                  >
                    Testar Conexão
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <input
                  value={modelDrafts[p.id] || ''}
                  onChange={(e) => setModelDrafts((prev) => ({ ...prev, [p.id]: e.target.value }))}
                  placeholder="Modelo (ex: gpt-4o-mini)"
                  className="bg-[#0E0E13] border border-zinc-800 rounded-lg px-3 py-1.5 text-xs font-mono text-white"
                />
                {p.id !== 'gemini' ? (
                  <>
                    <input
                      value={urlDrafts[p.id] || ''}
                      onChange={(e) => setUrlDrafts((prev) => ({ ...prev, [p.id]: e.target.value }))}
                      placeholder={p.kind === 'ollama' ? 'http://127.0.0.1:11434' : 'Base URL'}
                      className="bg-[#0E0E13] border border-zinc-800 rounded-lg px-3 py-1.5 text-xs font-mono text-white"
                    />
                    <div className="flex gap-2">
                      {p.kind !== 'ollama' && (
                        <input
                          type="password"
                          value={keyDrafts[p.id] || ''}
                          onChange={(e) => setKeyDrafts((prev) => ({ ...prev, [p.id]: e.target.value }))}
                          placeholder={p.hasCredential ? 'Credencial salva (digite para atualizar)' : 'API Key do provedor'}
                          className="flex-1 bg-[#0E0E13] border border-zinc-800 rounded-lg px-3 py-1.5 text-xs font-mono text-white"
                        />
                      )}
                      <button
                        type="button"
                        onClick={() => void handleSaveProvider(p)}
                        disabled={busyId === p.id}
                        className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white text-xs font-medium rounded-lg cursor-pointer"
                      >
                        Salvar
                      </button>
                    </div>
                  </>
                ) : (
                  <div className="sm:col-span-2 flex items-center text-[11px] text-zinc-500 px-2">
                    Chave GEMINI_API_KEY gerenciada exclusivamente pelas variáveis de ambiente/Secrets do servidor.
                  </div>
                )}
              </div>
              {p.lastError && <p className="text-[11px] text-amber-400 font-mono">{p.lastError}</p>}
            </div>
          ))}
        </div>
      </div>

      {/* Hosting & GitHub Vault */}
      <div className="bg-[#0E0E13] border border-zinc-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center gap-2 text-sm font-semibold text-white">
          <KeyRound className="w-4 h-4 text-red-500" />
          <span>Credenciais Cloud, Deploy & GitHub (Cofre do Servidor)</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {[...HOSTING_SLOTS.map((h) => ({ slot: h.id, label: h.label, hint: h.hint, testable: true })), { slot: 'github', label: 'GitHub Personal Access Token', hint: 'ghp_... / github_pat_...', testable: false }].map((item) => {
            const st = vaultStatus.find((v) => v.slot === item.slot);
            return (
              <div key={item.slot} className="p-3.5 rounded-lg bg-[#09090D] border border-zinc-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-zinc-200">{item.label}</span>
                  <span className={`font-mono text-[11px] ${st?.configured ? 'text-emerald-400' : 'text-zinc-500'}`}>
                    {st?.configured ? `CONFIGURADO (${st.source})` : 'CONFIGURATION_REQUIRED'}
                  </span>
                </div>
                <div className="flex gap-2">
                  <input
                    type="password"
                    value={keyDrafts[item.slot] || ''}
                    onChange={(e) => setKeyDrafts((prev) => ({ ...prev, [item.slot]: e.target.value }))}
                    placeholder={item.hint}
                    className="flex-1 bg-[#0E0E13] border border-zinc-800 rounded-lg px-3 py-1.5 text-xs font-mono text-white"
                  />
                  <button
                    type="button"
                    onClick={() => void handleSaveVaultToken(item.slot)}
                    disabled={busyId === item.slot}
                    className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white text-xs rounded-lg cursor-pointer"
                  >
                    Gravar
                  </button>
                  {item.testable && (
                    <button
                      type="button"
                      onClick={() => void handleTestHosting(item.slot as DeployProviderId)}
                      disabled={busyId === item.slot}
                      className="px-2.5 py-1.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-200 text-xs rounded-lg cursor-pointer"
                    >
                      <PlugZap className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* AI Request History */}
      <div className="bg-[#0E0E13] border border-zinc-800 rounded-xl p-5 space-y-3">
        <div className="text-sm font-semibold text-white">
          Histórico de Requisições & Consumo IA ({history.length})
        </div>
        {history.length === 0 ? (
          <p className="text-xs text-zinc-500">Nenhuma inferência registrada desde o último boot.</p>
        ) : (
          <div className="space-y-1.5 max-h-60 overflow-y-auto">
            {history.map((h) => (
              <div key={h.id} className="p-2.5 rounded bg-[#09090D] border border-zinc-800 text-xs flex items-center justify-between gap-3">
                <div className="truncate">
                  <span className={`font-mono mr-2 ${h.success ? 'text-emerald-400' : 'text-red-400'}`}>
                    [{h.providerId}:{h.model}]
                  </span>
                  <span className="text-zinc-300">{h.taskType}</span>
                  {h.error && <span className="text-red-400 ml-2">— {h.error}</span>}
                </div>
                <span className="font-mono text-zinc-500 shrink-0 tabular-nums">
                  {h.latencyMs}ms · ~{h.estimatedTokens}t
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
