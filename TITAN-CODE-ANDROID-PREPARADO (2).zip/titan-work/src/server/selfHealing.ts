import crypto from 'crypto';
import type {
  GeneratedFileItem,
  SelfHealingFinding,
  SelfHealingReport,
} from '../shared/titanTypes.ts';
import {
  validateCodeCompleteness,
  validateDependencies,
  validateSyntaxStatic,
} from '../shared/titanValidators.ts';
import { generateTextWithFallback } from './providerManager.ts';
import { getSystemCapabilities, runIsolatedCode } from './sandboxRunner.ts';

export async function runSelfHealingDiagnostic(params: {
  files: GeneratedFileItem[];
  applySafeFixes?: boolean;
  useAiFix?: boolean;
  adminApproved?: boolean;
}): Promise<SelfHealingReport> {
  const findings: SelfHealingFinding[] = [];
  const limitations: string[] = [];
  let currentFiles = params.files.map((f) => ({ ...f }));

  // 1. DETECÇÃO & 2. DIAGNÓSTICO
  const compCheck = validateCodeCompleteness(currentFiles);
  const depCheck = validateDependencies(currentFiles);
  const syntaxCheck = validateSyntaxStatic(currentFiles);
  const caps = await getSystemCapabilities();

  if (!compCheck.passed && compCheck.details) {
    for (const d of compCheck.details) {
      findings.push({
        id: `heal_${crypto.randomUUID().slice(0, 6)}`,
        category: 'syntax',
        severity: 'error',
        title: 'Placeholder ou função incompleta detectada',
        cause: d,
        proposedAction: 'Completar implementação real removendo TODO/FIXME/stubs.',
        autoFixSafe: Boolean(params.useAiFix),
        requiresAdminApproval: false,
        fixed: false,
        detail: d,
      });
    }
  }

  if (!depCheck.passed && depCheck.details) {
    for (const d of depCheck.details) {
      findings.push({
        id: `heal_${crypto.randomUUID().slice(0, 6)}`,
        category: 'dependency',
        severity: 'error',
        title: 'Import relativo quebrado',
        cause: d,
        proposedAction: 'Ajustar caminho de importação ou criar módulo ausente.',
        autoFixSafe: Boolean(params.useAiFix),
        requiresAdminApproval: false,
        fixed: false,
        detail: d,
      });
    }
  }

  if (!syntaxCheck.passed && syntaxCheck.details) {
    for (const d of syntaxCheck.details) {
      findings.push({
        id: `heal_${crypto.randomUUID().slice(0, 6)}`,
        category: 'syntax',
        severity: 'error',
        title: 'Erro sintático ou delimitador desbalanceado',
        cause: d,
        proposedAction: 'Corrigir JSON inválido ou balanceamento de blocos.',
        autoFixSafe: true,
        requiresAdminApproval: false,
        fixed: false,
        detail: d,
      });
    }
  }

  // Secret & Runtime checks
  for (const file of currentFiles) {
    if (/(api_key|secret|password|token)\s*=\s*['"][^'"]{8,}['"]/i.test(file.content)) {
      findings.push({
        id: `heal_${crypto.randomUUID().slice(0, 6)}`,
        category: 'config',
        severity: 'critical',
        title: `Possível segredo hardcoded em ${file.path}`,
        cause: 'Valor de credencial literal encontrado no código-fonte.',
        proposedAction: 'Mover credencial para variável de ambiente (.env / Server Vault).',
        autoFixSafe: false,
        requiresAdminApproval: true,
        fixed: false,
        detail: `Substitua o literal em ${file.path} por process.env / Vault.`,
      });
    }

    if (['Python', 'JavaScript', 'TypeScript'].includes(file.language)) {
      const execCheck = await runIsolatedCode({
        language: file.language,
        code: file.content,
        syntaxOnly: true,
      });
      if (!execCheck.syntaxValid) {
        findings.push({
          id: `heal_${crypto.randomUUID().slice(0, 6)}`,
          category: 'runtime',
          severity: 'error',
          title: `Falha de compilação/transpilação em ${file.path}`,
          cause: execCheck.stderr || 'Erro de sintaxe detectado pelo compilador real.',
          proposedAction: 'Aplicar correção sintática e revalidar compilador.',
          autoFixSafe: Boolean(params.useAiFix),
          requiresAdminApproval: false,
          fixed: false,
          detail: execCheck.stderr,
        });
      }
    }
  }

  if (!caps.geminiConfigured) {
    findings.push({
      id: `heal_${crypto.randomUUID().slice(0, 6)}`,
      category: 'integration',
      severity: 'warning',
      title: 'GEMINI_API_KEY não detectada no ambiente',
      cause: 'Variável de ambiente GEMINI_API_KEY ausente.',
      proposedAction: 'Configurar GEMINI_API_KEY nos Secrets ou habilitar provedor alternativo (OpenAI/Ollama).',
      autoFixSafe: false,
      requiresAdminApproval: true,
      fixed: false,
      detail: 'Sistema operando sem chave Gemini principal.',
    });
  }

  // 5. VALIDAÇÃO & 6. RECUPERAÇÃO (Safe Reversible Fixes Only)
  const fixedFiles: GeneratedFileItem[] = [];
  if (params.applySafeFixes && currentFiles.length > 0) {
    for (let i = 0; i < currentFiles.length; i++) {
      let file = { ...currentFiles[i] };
      let modified = false;

      // Safe deterministic fix 1: trailing whitespace & missing trailing newline + BOM strip
      const cleaned = file.content.replace(/^\uFEFF/, '').replace(/[ \t]+$/gm, '');
      if (cleaned !== file.content) {
        file.content = cleaned;
        modified = true;
      }

      // Safe deterministic fix 2: JSON pretty-repair if trailing comma
      if (file.path.toLowerCase().endsWith('.json')) {
        try {
          JSON.parse(file.content);
        } catch {
          const withoutTrailingComma = file.content.replace(/,\s*([}\]])/g, '$1');
          try {
            JSON.parse(withoutTrailingComma);
            file.content = JSON.stringify(JSON.parse(withoutTrailingComma), null, 2);
            modified = true;
            for (const f of findings) {
              if (f.category === 'syntax' && f.detail.includes(file.path)) f.fixed = true;
            }
          } catch {
            // Cannot deterministically repair malformed JSON without AI
          }
        }
      }

      // Optional AI Repair when requested and safe findings exist
      if (params.useAiFix && findings.some((f) => !f.fixed && f.autoFixSafe && f.detail.includes(file.path))) {
        try {
          const issueText = findings
            .filter((f) => !f.fixed && f.autoFixSafe && f.detail.includes(file.path))
            .map((f) => `- ${f.title}: ${f.cause}`)
            .join('\n');
          const aiResp = await generateTextWithFallback({
            taskType: 'self-heal-fix',
            systemInstruction:
              'Você é o TITAN Self-Healing Engine. Retorne APENAS o código-fonte corrigido e completo do arquivo solicitado, sem markdown wrapper ou explicações fora do código.',
            messages: [
              {
                role: 'user',
                content: `Arquivo: ${file.path} (${file.language})\nProblemas:\n${issueText}\n\nCódigo atual:\n${file.content}`,
              },
            ],
          });
          const stripped = aiResp.text
            .replace(/^```[a-zA-Z0-9]*\n/, '')
            .replace(/\n```$/, '')
            .trim();
          if (stripped.length > 20) {
            file.content = stripped;
            modified = true;
            for (const f of findings) {
              if (f.autoFixSafe && f.detail.includes(file.path)) f.fixed = true;
            }
          }
        } catch (err) {
          limitations.push(`Auto-Fix por IA para ${file.path} falhou: ${err instanceof Error ? err.message : String(err)}`);
        }
      }

      if (modified) {
        currentFiles[i] = file;
        fixedFiles.push(file);
      }
    }
  }

  const hasCriticalUnfixed = findings.some((f) => f.severity === 'critical' && !f.fixed);
  const hasFixed = findings.some((f) => f.fixed);

  return {
    id: `healrep_${crypto.randomUUID().slice(0, 8)}`,
    executedAt: new Date().toISOString(),
    stages: [
      { stage: 'DETECÇÃO', status: findings.length > 0 ? 'WARNING' : 'OK', summary: `${findings.length} anomalia(s) identificada(s) em ${currentFiles.length} arquivo(s).` },
      { stage: 'DIAGNÓSTICO', status: hasCriticalUnfixed ? 'BLOCKED' : 'OK', summary: `Verificação estática, dependências, segredos e compiladores (${caps.nodeVersion}).` },
      { stage: 'CAUSA', status: 'OK', summary: findings.length > 0 ? findings[0].cause : 'Nenhuma causa raiz crítica detectada.' },
      { stage: 'PROPOSTA', status: 'OK', summary: findings.length > 0 ? `${findings.filter((f) => f.autoFixSafe).length} correção(ões) segura(s) disponível(is).` : 'Sistema íntegro.' },
      { stage: 'VALIDAÇÃO', status: 'OK', summary: 'Política de segurança: backup antes de alterações e bloqueio de mudanças críticas sem aprovação Admin.' },
      { stage: 'RECUPERAÇÃO', status: hasFixed ? 'FIXED' : params.applySafeFixes ? 'OK' : 'WARNING', summary: hasFixed ? `${fixedFiles.length} arquivo(s) corrigido(s) e revalidado(s).` : 'Pronto para aplicar correções seguras.' },
    ],
    findings,
    fixedFiles: fixedFiles.length > 0 ? fixedFiles : undefined,
    limitations,
  };
}
