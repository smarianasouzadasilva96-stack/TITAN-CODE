import { GoogleGenAI, Type } from '@google/genai';
import crypto from 'crypto';
import type {
  DeliveryMode,
  FileKind,
  GeneratedFileItem,
  GenerationPlan,
  GenerationResult,
  PipelineStepLog,
  ProjectType,
  ValidatorResult,
} from '../shared/titanTypes.ts';
import {
  computeFinalDelivery,
  detectLanguageAndEnvironment,
  detectSingleFileIntent,
  validateCodeCompleteness,
  validateDependencies,
  validateLanguageMatch,
  validateProjectCompleteness,
  validateRequirementMatch,
  validateSingleFile,
  validateSyntaxStatic,
} from '../shared/titanValidators.ts';
import { getSystemCapabilities, runIsolatedCode } from './sandboxRunner.ts';

const MODEL_NAME = 'gemini-4-hydrogen';

function getAiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || !apiKey.trim()) {
    return null;
  }
  return new GoogleGenAI({
    apiKey: apiKey.trim(),
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function nowIso(): string {
  return new Date().toISOString();
}

const VALID_FILE_KINDS = new Set<FileKind>([
  'Script',
  'LocalScript',
  'ModuleScript',
  'Source',
  'Config',
  'Manifest',
  'Doc',
]);

function normalizeFileKind(raw?: string): FileKind {
  if (raw && VALID_FILE_KINDS.has(raw as FileKind)) {
    return raw as FileKind;
  }
  return 'Source';
}

const STRUCTURED_GENERATION_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    objective: { type: Type.STRING, description: 'Clear engineering objective.' },
    architecture: { type: Type.STRING, description: 'Concise architecture plan.' },
    dependencies: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: 'Required external packages or platform services.',
    },
    testCriteria: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: 'Verification criteria for the generated code.',
    },
    explanation: {
      type: Type.STRING,
      description: 'Concise technical explanation in Portuguese of how the generated implementation works and how to run it.',
    },
    files: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          path: { type: Type.STRING, description: 'File path such as FlySystem.client.luau or app/src/main/java/com/example/MainActivity.kt' },
          language: { type: Type.STRING, description: 'Exact programming language of this file.' },
          fileKind: {
            type: Type.STRING,
            description: 'One of: Script, LocalScript, ModuleScript, Source, Config, Manifest, Doc',
          },
          content: {
            type: Type.STRING,
            description: 'Complete, production-ready, non-truncated source code for this file. Never include TODOs or placeholder functions.',
          },
        },
        required: ['path', 'language', 'fileKind', 'content'],
      },
    },
  },
  required: ['objective', 'architecture', 'dependencies', 'testCriteria', 'explanation', 'files'],
};

interface RawAiGenerationPayload {
  objective: string;
  architecture: string;
  dependencies: string[];
  testCriteria: string[];
  explanation: string;
  files: Array<{
    path: string;
    language: string;
    fileKind: string;
    content: string;
  }>;
}

export async function runEngineeringPipeline(params: {
  module: 'script-studio' | 'project-builder' | 'code-generator' | 'luau-lab' | 'apk-builder';
  prompt: string;
  explicitLanguage?: string;
  explicitEnvironment?: string;
  deliveryMode?: DeliveryMode;
  projectTypeOverride?: ProjectType;
  apkConfig?: {
    appName: string;
    packageName: string;
    versionName: string;
    versionCode: number;
    orientation: string;
    permissions: string[];
  };
}): Promise<GenerationResult> {
  const taskId = `task_${crypto.randomUUID().slice(0, 12)}`;
  const pipelineLogs: PipelineStepLog[] = [];
  const caps = await getSystemCapabilities();

  const detection = detectLanguageAndEnvironment(
    params.prompt,
    params.explicitLanguage,
    params.explicitEnvironment,
  );
  const projectType = params.projectTypeOverride || detection.projectType;
  const singleFileIntent = detectSingleFileIntent(
    params.prompt,
    params.module === 'project-builder' || params.module === 'apk-builder'
      ? 'multi-file'
      : params.deliveryMode || 'auto',
  );

  pipelineLogs.push({
    state: 'PLANNING',
    timestamp: nowIso(),
    detail: `Detectado: Linguagem=${detection.language}, Ambiente=${detection.environment}, Modo=${singleFileIntent.singleFile ? 'Arquivo Único' : 'Múltiplos Arquivos'}.`,
  });

  const ai = getAiClient();
  if (!ai) {
    return {
      taskId,
      status: 'BLOCKED',
      plan: {
        objective: params.prompt,
        language: detection.language,
        environment: detection.environment,
        architecture: 'Pipeline bloqueado por ausência de GEMINI_API_KEY no servidor.',
        deliveryMode: singleFileIntent.singleFile ? 'single-file' : 'multi-file',
        singleFileReason: singleFileIntent.reason,
        dependencies: [],
        plannedFiles: [],
        testCriteria: [],
      },
      files: [],
      explanation: 'GEMINI_API_KEY não configurada no ambiente do servidor. Configure a chave na seção Settings > Secrets para ativar a inferência real.',
      validators: [
        {
          name: 'FinalDeliveryValidator',
          executed: true,
          passed: false,
          severity: 'blocked',
          message: 'Modelo de IA indisponível (GEMINI_API_KEY ausente). Nenhuma resposta simulada foi gerada.',
        },
      ],
      pipelineLogs: [
        ...pipelineLogs,
        { state: 'BLOCKED', timestamp: nowIso(), detail: 'Execução bloqueada: GEMINI_API_KEY ausente.' },
      ],
      repairAttempts: 0,
      modelUsed: MODEL_NAME,
    };
  }

  const systemInstruction = buildEngineeringSystemInstruction({
    module: params.module,
    language: detection.language,
    environment: detection.environment,
    projectType,
    singleFile: singleFileIntent.singleFile,
    apkConfig: params.apkConfig,
  });

  const startedAt = Date.now();
  let currentPrompt = params.prompt;
  let repairAttempts = 0;
  let lastPayload: RawAiGenerationPayload | null = null;
  let lastFiles: GeneratedFileItem[] = [];
  let lastValidators: ValidatorResult[] = [];
  let lastExecEvidence: GenerationResult['executionEvidence'] | undefined;

  for (let attempt = 0; attempt < 2; attempt++) {
    pipelineLogs.push({
      state: attempt === 0 ? 'GENERATING' : 'NEEDS_CORRECTION',
      timestamp: nowIso(),
      detail:
        attempt === 0
          ? `Gerando código real em ${detection.language} (${detection.environment}) com ${MODEL_NAME}...`
          : `Executando ciclo de autocorreção #${attempt} com base nos validadores reprovados...`,
    });

    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: currentPrompt,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: STRUCTURED_GENERATION_SCHEMA,
      },
    });

    const rawText = (response.text ?? '').trim();
    try {
      lastPayload = JSON.parse(rawText) as RawAiGenerationPayload;
    } catch {
      lastPayload = null;
    }

    if (!lastPayload || !Array.isArray(lastPayload.files) || lastPayload.files.length === 0) {
      repairAttempts += 1;
      currentPrompt = `${params.prompt}\n\nATENÇÃO: A tentativa anterior não retornou JSON válido com arquivos completos. Retorne JSON válido conforme o schema, com implementação real e completa em ${detection.language}.`;
      continue;
    }

    pipelineLogs.push({
      state: 'IMPLEMENTING',
      timestamp: nowIso(),
      detail: `${lastPayload.files.length} arquivo(s) estruturado(s). Aplicando validadores independentes...`,
    });

    lastFiles = lastPayload.files.map((f) => ({
      path: f.path,
      content: f.content,
      language: f.language || detection.language,
      fileKind: normalizeFileKind(f.fileKind),
    }));

    pipelineLogs.push({
      state: 'VALIDATING',
      timestamp: nowIso(),
      detail: 'Executando validadores independentes de linguagem, completude, dependências e sintaxe.',
    });

    const vLang = validateLanguageMatch(detection.language, detection.environment, lastFiles);
    const vReq = validateRequirementMatch(params.prompt, lastFiles);
    const vComp = validateCodeCompleteness(lastFiles);
    const vSingle = validateSingleFile(singleFileIntent.singleFile, lastFiles);
    const vProj = validateProjectCompleteness(projectType, singleFileIntent.singleFile, params.prompt, lastFiles);
    const vDep = validateDependencies(lastFiles);
    const vSyntax = validateSyntaxStatic(lastFiles);

    pipelineLogs.push({
      state: 'TESTING',
      timestamp: nowIso(),
      detail: 'Verificando compilação/sintaxe/execução no ambiente disponível...',
    });

    const primaryFile = lastFiles[0];
    const runResult = primaryFile
      ? await runIsolatedCode({
          language: detection.language,
          code: primaryFile.content,
          syntaxOnly: true,
        })
      : null;

    const vBuild: ValidatorResult =
      projectType === 'android'
        ? {
            name: 'BuildValidator',
            executed: false,
            passed: caps.androidSdkAvailable && caps.gradleAvailable,
            severity: 'blocked',
            message: caps.androidSdkAvailable
              ? 'Android SDK presente.'
              : 'Build APK/Gradle não executado neste servidor (Android SDK e Gradle não instalados). Projeto fonte completo pronto para exportação.',
          }
        : runResult && (detection.language === 'Python' || detection.language === 'JavaScript' || detection.language === 'TypeScript')
        ? {
            name: 'BuildValidator',
            executed: true,
            passed: runResult.syntaxValid,
            severity: runResult.syntaxValid ? 'pass' : 'error',
            message: runResult.syntaxValid
              ? `Compilação/checagem real aprovada via ${runResult.runtime}.`
              : `Erro real de compilação/sintaxe: ${runResult.stderr}`,
          }
        : {
            name: 'BuildValidator',
            executed: false,
            passed: true,
            severity: 'warning',
            message: `Compilador nativo para ${detection.language} (${detection.environment}) não instalado no container; validação estática executada.`,
          };

    let vTest: ValidatorResult;
    if (detection.language === 'Python' || detection.language === 'JavaScript' || detection.language === 'TypeScript') {
      const hasInputWait = /\binput\s*\(/.test(primaryFile?.content || '');
      if (hasInputWait) {
        vTest = {
          name: 'TestValidator',
          executed: true,
          passed: runResult ? runResult.syntaxValid : true,
          severity: 'pass',
          message: 'Script interativo (usa input()). Sintaxe verificada com python3 -m py_compile; pronto para execução no sandbox com stdin.',
        };
      } else if (primaryFile) {
        const execRes = await runIsolatedCode({
          language: detection.language,
          code: primaryFile.content,
          syntaxOnly: false,
        });
        lastExecEvidence = {
          executed: execRes.executed,
          runtime: execRes.runtime,
          exitCode: execRes.exitCode,
          stdout: execRes.stdout,
          stderr: execRes.stderr,
          durationMs: execRes.durationMs,
        };
        const ok = execRes.exitCode === 0;
        vTest = {
          name: 'TestValidator',
          executed: execRes.executed,
          passed: ok,
          severity: ok ? 'pass' : 'error',
          message: ok
            ? `Execução isolada concluída com exit code 0 em ${execRes.durationMs}ms.`
            : `Falha na execução isolada (exit ${execRes.exitCode}): ${execRes.stderr}`,
        };
      } else {
        vTest = {
          name: 'TestValidator',
          executed: false,
          passed: false,
          severity: 'error',
          message: 'Nenhum arquivo primário encontrado para testar.',
        };
      }
    } else {
      vTest = {
        name: 'TestValidator',
        executed: false,
        passed: true,
        severity: 'warning',
        message: `Testes automatizados em runtime ${detection.environment} devem ser executados no ambiente alvo.`,
      };
    }

    lastValidators = [vLang, vReq, vComp, vSingle, vProj, vDep, vSyntax, vBuild, vTest];
    const delivery = computeFinalDelivery(lastValidators);
    lastValidators.push(delivery.summaryValidator);

    if (delivery.status === 'COMPLETED') {
      pipelineLogs.push({
        state: 'COMPLETED',
        timestamp: nowIso(),
        detail: 'Todos os validadores obrigatórios aprovados. Entrega concluída com evidências.',
      });
      break;
    }

    if (attempt === 0) {
      repairAttempts += 1;
      const failureSummary = lastValidators
        .filter((v) => !v.passed)
        .map((v) => `- ${v.name}: ${v.message} ${(v.details || []).join(' | ')}`)
        .join('\n');
      currentPrompt = `${params.prompt}\n\nCORREÇÃO OBRIGATÓRIA — A tentativa anterior falhou nos seguintes validadores:\n${failureSummary}\n\nCorrija TODOS os problemas acima mantendo a linguagem exata (${detection.language}), o ambiente (${detection.environment}) e implementação 100% completa sem placeholders.`;
    } else {
      pipelineLogs.push({
        state: 'NEEDS_CORRECTION',
        timestamp: nowIso(),
        detail: 'Após tentativa de autocorreção, ainda restam falhas reportadas pelos validadores.',
      });
    }
  }

  const finalCheck = computeFinalDelivery(lastValidators);
  const limitations: string[] = [];
  if (projectType === 'android' && !caps.androidSdkAvailable) {
    limitations.push('Android SDK e Gradle não estão instalados neste ambiente servidor; portanto, o código Android Kotlin/XML/Gradle completo foi gerado e validado estaticamente, mas a compilação binária de APK requer Android Studio ou ambiente com JDK 17 + Android SDK.');
  }
  if (detection.language === 'Luau') {
    limitations.push('Luau/Roblox Studio Engine não está instalado no servidor Linux; a validação sintática e de APIs Roblox foi executada estaticamente.');
  }

  const plan: GenerationPlan = {
    objective: lastPayload?.objective || params.prompt,
    language: detection.language,
    environment: detection.environment,
    architecture: lastPayload?.architecture || `${detection.language} (${detection.environment})`,
    deliveryMode: singleFileIntent.singleFile ? 'single-file' : 'multi-file',
    singleFileReason: singleFileIntent.reason,
    dependencies: lastPayload?.dependencies || [],
    plannedFiles: lastFiles.map((f) => f.path),
    testCriteria: lastPayload?.testCriteria || [],
  };

  return {
    taskId,
    status: lastFiles.length === 0 ? 'NEEDS_CORRECTION' : finalCheck.status,
    plan,
    files: lastFiles,
    explanation:
      lastPayload?.explanation ||
      'Não foi possível concluir a geração estruturada.',
    validators: lastValidators,
    pipelineLogs,
    repairAttempts,
    executionEvidence: lastExecEvidence,
    limitations: limitations.length > 0 ? limitations : undefined,
    modelUsed: MODEL_NAME,
    providerUsed: 'gemini',
    durationMs: Date.now() - startedAt,
  };
}

function buildEngineeringSystemInstruction(ctx: {
  module: string;
  language: string;
  environment: string;
  projectType: ProjectType;
  singleFile: boolean;
  apkConfig?: {
    appName: string;
    packageName: string;
    versionName: string;
    versionCode: number;
    orientation: string;
    permissions: string[];
  };
}): string {
  const apkNote = ctx.apkConfig
    ? `\nCONFIGURAÇÃO ANDROID OBRIGATÓRIA:\n- App Name: ${ctx.apkConfig.appName}\n- Package Name: ${ctx.apkConfig.packageName}\n- Version Name: ${ctx.apkConfig.versionName}\n- Version Code: ${ctx.apkConfig.versionCode}\n- Orientation: ${ctx.apkConfig.orientation}\n- Permissions: ${ctx.apkConfig.permissions.join(', ') || 'INTERNET'}`
    : '';

  return `Você é o motor de engenharia de software real do TITAN CODE (módulo: ${ctx.module}).

REGRAS ABSOLUTAS E INVIOLÁVEIS:
1. LINGUAGEM OBRIGATÓRIA: Gere código exclusivamente em ${ctx.language} para o ambiente ${ctx.environment}.
2. NUNCA substitua o pedido por estruturas genéricas como "ExecutionPayload", "runTask()", "Processado: ..." ou wrappers em TypeScript quando outra linguagem foi solicitada.
3. MODO DE ENTREGA: ${
    ctx.singleFile
      ? 'SINGLE-FILE MODE ATIVO — Gere EXATAMENTE 1 arquivo auto-contido, completo, sem imports relativos locais (./ ou ../), sem require(script.Parent), pronto para copiar e executar.'
      : 'MULTI-FILE PROJECT MODE ATIVO — Gere todos os arquivos necessários da arquitetura com implementação completa em CADA arquivo.'
  }
4. ZERO PLACEHOLDERS: Nunca escreva TODO, FIXME, "...rest of code", funções vazias, ou MainActivity.onCreate() vazia.
5. REGRAS ESPECÍFICAS POR DOMÍNIO:
   - Se for Luau / Roblox:
     * Diferencie claramente Script (Server), LocalScript (Client) e ModuleScript (Shared) no campo fileKind e no caminho do arquivo (ex: StarterPlayerScripts/FlyController.client.luau, ServerScriptService/FlightServer.server.luau).
     * Use exclusivamente APIs reais do Roblox (Players, RunService, UserInputService, ReplicatedStorage, Workspace, LinearVelocity/BodyVelocity, AlignOrientation, DataStoreService).
     * Nunca invente APIs de executores ou bypass de anticheat, e nunca dê autoridade de servidor ao cliente.
     * Para scripts de voo (Fly) em arquivo único: crie um LocalScript completo usando Players.LocalPlayer, UserInputService, RunService.RenderStepped, Workspace.CurrentCamera, LinearVelocity (ou BodyVelocity fallback) e AlignOrientation, com teclas de ativação (F), movimentação WASD + Space/LeftControl, controle de velocidade e limpeza segura no CharacterAdded/Died.
   - Se for Android / Kotlin:
     * Inclua no mínimo: settings.gradle.kts, build.gradle.kts, app/build.gradle.kts, app/src/main/AndroidManifest.xml, app/src/main/java/<package>/MainActivity.kt, app/src/main/res/values/strings.xml, README.md.
     * MainActivity.kt DEVE conter uma interface funcional completa (Jetpack Compose ou Android Views com listeners e estado real).
     * README.md DEVE conter documentação técnica real de arquitetura, build e execução, NUNCA copiar o prompt original.
   - Se for Python:
     * Inclua tipagem, tratamento de erros (try/except, ZeroDivisionError, ValueError), funções reais e bloco if __name__ == "__main__":.
   - Se for Web (HTML/CSS/JS):
     * Entregue interface visual completa, semântica, responsiva e com interações reais em JavaScript.${apkNote}`;
}

export async function runAiChat(params: {
  mode: 'core-ai' | 'admin-ai' | 'agent';
  message: string;
  history: Array<{ role: 'user' | 'assistant'; content: string }>;
  workspaceContext?: string;
  adminKnowledge?: Array<{ title: string; category: string; content: string }>;
  agentProfile?: { id: string; name: string; objective: string; instructions: string };
  systemMetricsSummary?: string;
  preferredProviderId?: string;
}): Promise<{ reply: string; modelUsed: string; providerId?: string; blocked?: boolean }> {
  let systemInstruction = '';
  if (params.mode === 'core-ai') {
    systemInstruction = `Você é o TITAN CORE AI, assistente principal de engenharia de software da plataforma TITAN CODE.
Você conhece todos os 28 módulos do ecossistema (Deploy Center, Web-to-APK, Performance Engine, Quality Engine, Control Center, AI Orchestrator, Test Lab, Security Center, Git Control, Cloud Files, Automation Center, Integrations Center, Script Studio, Project Builder, Luau Lab, APK Builder, Web Studio, Database Studio, API Studio, Debugger Pro, Toolbox, Agents, Workspace).
Responda em português com precisão técnica, código real quando solicitado (respeitando a linguagem pedida pelo usuário), zero placeholders e orientação prática.
${params.workspaceContext ? `\nCONTEXTO ATUAL DO WORKSPACE DO USUÁRIO:\n${params.workspaceContext}` : ''}`;
  } else if (params.mode === 'admin-ai') {
    const kbText =
      params.adminKnowledge && params.adminKnowledge.length > 0
        ? params.adminKnowledge.map((k) => `[${k.category}] ${k.title}: ${k.content}`).join('\n')
        : 'Nenhum procedimento cadastrado na base de conhecimento administrativa ainda.';
    systemInstruction = `Você é o TITAN ADMIN AI, assistente exclusivo do administrador da plataforma TITAN CODE.
Capacidades: consultar estado da plataforma, analisar logs e erros, monitorar builds, deploys, filas, revisar segurança, recomendar melhorias e aplicar procedimentos ensinados pelo administrador.
Operações destrutivas ou críticas SEMPRE exigem confirmação explícita antes da execução.
${params.systemMetricsSummary ? `\nESTADO REAL DA PLATAFORMA:\n${params.systemMetricsSummary}` : ''}
\nBASE DE CONHECIMENTO ADMINISTRATIVA PERSISTENTE:\n${kbText}`;
  } else {
    const agent = params.agentProfile;
    systemInstruction = `Você é o agente especializado "${agent?.name || 'Code Agent'}" do ecossistema TITAN AGENT.
Objetivo: ${agent?.objective || 'Executar tarefas de engenharia com rigor.'}
Instruções operacionais: ${agent?.instructions || 'Entregue análise técnica e código completo.'}
Responda de forma objetiva, estruturada e com código ou plano acionável real.`;
  }

  try {
    const { generateTextWithFallback } = await import('./providerManager.ts');
    const result = await generateTextWithFallback({
      taskType: `chat:${params.mode}`,
      systemInstruction,
      messages: [
        ...params.history.slice(-14),
        { role: 'user', content: params.message },
      ],
      preferredProviderId: params.preferredProviderId,
    });
    return {
      reply: result.text,
      modelUsed: result.modelUsed,
      providerId: result.providerId,
    };
  } catch (err) {
    return {
      reply: `TITAN AI indisponível no momento: ${err instanceof Error ? err.message : String(err)}. Nenhuma resposta simulada foi gerada.`,
      modelUsed: MODEL_NAME,
      blocked: true,
    };
  }
}

export async function runStaticAndAiAnalysis(params: {
  code: string;
  language: string;
  useAi: boolean;
}): Promise<{
  staticIssues: Array<{ line: number; severity: 'info' | 'warning' | 'error' | 'critical'; rule: string; message: string }>;
  unusedVars: string[];
  securityFindings: string[];
  aiReview?: string;
}> {
  const lines = params.code.split('\n');
  const staticIssues: Array<{ line: number; severity: 'info' | 'warning' | 'error' | 'critical'; rule: string; message: string }> = [];
  const unusedVars: string[] = [];
  const securityFindings: string[] = [];

  lines.forEach((lineText, idx) => {
    const lineNum = idx + 1;
    if (/\beval\s*\(/.test(lineText) || /\bnew Function\s*\(/.test(lineText)) {
      staticIssues.push({ line: lineNum, severity: 'critical', rule: 'no-eval', message: 'Uso de eval()/new Function() detectado (risco de execução arbitrária).' });
      securityFindings.push(`Linha ${lineNum}: Uso perigoso de eval/Function.`);
    }
    if (/innerHTML\s*=/.test(lineText) || /dangerouslySetInnerHTML/.test(lineText)) {
      staticIssues.push({ line: lineNum, severity: 'warning', rule: 'xss-sink', message: 'Atribuição direta a innerHTML detectada (verifique sanitização contra XSS).' });
      securityFindings.push(`Linha ${lineNum}: Potencial vetor XSS via innerHTML.`);
    }
    if (/(api_key|secret|password|token)\s*=\s*['"][^'"]{8,}['"]/i.test(lineText)) {
      staticIssues.push({ line: lineNum, severity: 'critical', rule: 'hardcoded-secret', message: 'Possível segredo ou credencial hardcoded no código.' });
      securityFindings.push(`Linha ${lineNum}: Possível credencial exposta no código-fonte.`);
    }
    if (/\bTODO\b|\bFIXME\b/.test(lineText)) {
      staticIssues.push({ line: lineNum, severity: 'info', rule: 'pending-marker', message: 'Marcador TODO/FIXME pendente encontrado.' });
    }
    if (/SELECT\s+.*\+\s*[a-zA-Z_]/i.test(lineText) || /f["']SELECT\s+.*\{/.test(lineText)) {
      staticIssues.push({ line: lineNum, severity: 'critical', rule: 'sql-injection', message: 'Possível concatenação direta em query SQL (use queries parametrizadas).' });
      securityFindings.push(`Linha ${lineNum}: Risco de SQL Injection por interpolação/concatenação.`);
    }
  });

  const declMatches = [...params.code.matchAll(/\b(?:const|let|var|local)\s+([a-zA-Z_][a-zA-Z0-9_]*)\b/g)];
  for (const m of declMatches) {
    const varName = m[1];
    if (varName.startsWith('_')) continue;
    const occurrences = (params.code.match(new RegExp(`\\b${varName}\\b`, 'g')) || []).length;
    if (occurrences === 1) {
      unusedVars.push(varName);
    }
  }

  let aiReview: string | undefined;
  if (params.useAi) {
    try {
      const { generateTextWithFallback } = await import('./providerManager.ts');
      const resp = await generateTextWithFallback({
        taskType: 'code-review',
        systemInstruction: 'Você é o TITAN DEBUGGER PRO. Seja técnico, direto e objetivo em português.',
        messages: [
          {
            role: 'user',
            content: `Analise o seguinte código em ${params.language}, liste bugs reais, riscos de segurança e forneça uma versão corrigida se necessário:\n\n\`\`\`${params.language}\n${params.code}\n\`\`\``,
          },
        ],
      });
      aiReview = resp.text;
    } catch (err) {
      aiReview = `Revisão por IA indisponível (${err instanceof Error ? err.message : String(err)}). Exibindo análise estática determinística.`;
    }
  }

  return { staticIssues, unusedVars, securityFindings, aiReview };
}

export function routeOrchestratorIntent(prompt: string): {
  targetModule: import('../shared/titanTypes.ts').NavSectionId;
  reason: string;
  priority: 'HIGH' | 'NORMAL' | 'LOW';
  steps: string[];
} {
  const lower = prompt.toLowerCase();
  if (/\b(deploy|hospedar|render|vercel|netlify|railway|cloudflare|dockerfile|dom[ií]nio|dns|ssl)\b/.test(lower)) {
    return {
      targetModule: 'deploy-center',
      reason: 'Intenção de publicação, infraestrutura Cloud ou verificação DNS/TLS detectada.',
      priority: 'HIGH',
      steps: ['Analisar stack do projeto', 'Gerar Dockerfile/manifests', 'Validar credenciais e executar deploy/probe'],
    };
  }
  if (/\b(web-to-apk|webview|twa|assetlinks|empacotar site|converter site em apk)\b/.test(lower)) {
    return {
      targetModule: 'web-to-apk',
      reason: 'Conversão de aplicação Web/PWA em pacote Android WebView/TWA/Híbrido.',
      priority: 'HIGH',
      steps: ['Selecionar modo WebView/TWA/Híbrido', 'Configurar com.titancode.app', 'Gerar projeto Android + CI Gradle'],
    };
  }
  if (/\b(android|apk nativo|kotlin|jetpack compose)\b/.test(lower)) {
    return {
      targetModule: 'apk-builder',
      reason: 'Criação de aplicativo Android Kotlin nativo.',
      priority: 'NORMAL',
      steps: ['Planejar arquitetura Android', 'Gerar MainActivity + Manifest + Gradle', 'Validar completude'],
    };
  }
  if (/\b(luau|roblox|localscript|modulescript|fly)\b/.test(lower)) {
    return {
      targetModule: 'luau-lab',
      reason: 'Engenharia Luau/Roblox especializada detectada.',
      priority: 'NORMAL',
      steps: ['Validar escopo Server/Client/Shared', 'Gerar script Luau validado', 'Checar delimitadores e APIs Roblox'],
    };
  }
  if (/\b(git|github|commit|branch|pull request|clonar)\b/.test(lower)) {
    return {
      targetModule: 'git-control',
      reason: 'Operação de controle de versão Git/GitHub.',
      priority: 'NORMAL',
      steps: ['Inspecionar repositório', 'Comparar diff/commits', 'Sincronizar com Workspace'],
    };
  }
  if (/\b(seguran[çc]a|vulnerabilidade|secret|leak|xss|sql injection|auditoria)\b/.test(lower)) {
    return {
      targetModule: 'security-center',
      reason: 'Auditoria de segurança e detecção de vulnerabilidades.',
      priority: 'HIGH',
      steps: ['Escanear arquivos por segredos e sinks', 'Classificar severidades', 'Gerar recomendações'],
    };
  }
  if (/\b(corrigir|auto.?heal|reparar|bug|erro|quebrado)\b/.test(lower)) {
    return {
      targetModule: 'quality-engine',
      reason: 'Diagnóstico e reparo automático de código.',
      priority: 'HIGH',
      steps: ['Criar backup de segurança', 'Executar 10 validadores + Self-Healing', 'Aplicar correções seguras'],
    };
  }
  if (/\b(teste|unit|testar|aceita[çc][ãa]o)\b/.test(lower)) {
    return {
      targetModule: 'test-lab',
      reason: 'Execução de testes automatizados e verificação.',
      priority: 'NORMAL',
      steps: ['Executar suíte real no sandbox', 'Validar APIs', 'Emitir relatório PASSED/FAILED/NOT_EXECUTED'],
    };
  }
  if (/\b(projeto|fullstack|multi-arquivo|estrutura completa)\b/.test(lower)) {
    return {
      targetModule: 'project-builder',
      reason: 'Arquitetura multi-arquivo solicitada.',
      priority: 'NORMAL',
      steps: ['Planejar estrutura completa', 'Gerar arquivos sem placeholders', 'Salvar no Workspace'],
    };
  }
  return {
    targetModule: 'script-studio',
    reason: 'Geração de script direto ou programa universal.',
    priority: 'NORMAL',
    steps: ['Detectar linguagem e modo single-file', 'Gerar e testar no sandbox', 'Validar entrega'],
  };
}

