import { GoogleGenAI } from '@google/genai';
import crypto from 'crypto';
import type {
  AiProviderConfigSummary,
  AiProviderKind,
  AiRequestHistoryEntry,
  IntegrationStatus,
} from '../shared/titanTypes.ts';
import { deleteVaultSecret, getVaultSecret, hasVaultSecret, setVaultSecret } from './vaultService.ts';

interface ProviderInternalConfig {
  id: string;
  kind: AiProviderKind;
  name: string;
  model: string;
  baseUrl?: string;
  enabled: boolean;
  priority: number;
  vaultSlot: string;
  status: IntegrationStatus;
  lastCheckedAt?: string;
  lastError?: string;
  requestCount: number;
  estimatedTokens: number;
}

const providers = new Map<string, ProviderInternalConfig>([
  [
    'gemini',
    {
      id: 'gemini',
      kind: 'gemini',
      name: 'Google Gemini (Server Env)',
      model: 'gemini-4-hydrogen',
      enabled: true,
      priority: 1,
      vaultSlot: 'gemini',
      status: hasVaultSecret('gemini') ? 'CONNECTED' : 'CONFIGURATION_REQUIRED',
      requestCount: 0,
      estimatedTokens: 0,
    },
  ],
  [
    'openai',
    {
      id: 'openai',
      kind: 'openai',
      name: 'OpenAI Official API',
      model: 'gpt-4o-mini',
      baseUrl: 'https://api.openai.com/v1',
      enabled: false,
      priority: 2,
      vaultSlot: 'openai',
      status: hasVaultSecret('openai') ? 'CONNECTED' : 'CONFIGURATION_REQUIRED',
      requestCount: 0,
      estimatedTokens: 0,
    },
  ],
  [
    'anthropic',
    {
      id: 'anthropic',
      kind: 'anthropic',
      name: 'Anthropic Claude API',
      model: 'claude-3-5-sonnet-latest',
      baseUrl: 'https://api.anthropic.com/v1',
      enabled: false,
      priority: 3,
      vaultSlot: 'anthropic',
      status: hasVaultSecret('anthropic') ? 'CONNECTED' : 'CONFIGURATION_REQUIRED',
      requestCount: 0,
      estimatedTokens: 0,
    },
  ],
  [
    'openrouter',
    {
      id: 'openrouter',
      kind: 'openrouter',
      name: 'OpenRouter Multi-Model',
      model: 'openai/gpt-4o-mini',
      baseUrl: 'https://openrouter.ai/api/v1',
      enabled: false,
      priority: 4,
      vaultSlot: 'openrouter',
      status: hasVaultSecret('openrouter') ? 'CONNECTED' : 'CONFIGURATION_REQUIRED',
      requestCount: 0,
      estimatedTokens: 0,
    },
  ],
  [
    'ollama',
    {
      id: 'ollama',
      kind: 'ollama',
      name: 'Ollama Local / Self-Hosted',
      model: 'qwen2.5-coder:7b',
      baseUrl: process.env.OLLAMA_BASE_URL || 'http://127.0.0.1:11434',
      enabled: false,
      priority: 5,
      vaultSlot: 'ollama_url',
      status: 'DISCONNECTED',
      requestCount: 0,
      estimatedTokens: 0,
    },
  ],
]);

const requestHistory: AiRequestHistoryEntry[] = [];

function recordHistory(entry: Omit<AiRequestHistoryEntry, 'id' | 'timestamp'>): void {
  requestHistory.unshift({
    ...entry,
    id: `aireq_${crypto.randomUUID().slice(0, 8)}`,
    timestamp: new Date().toISOString(),
  });
  if (requestHistory.length > 60) {
    requestHistory.pop();
  }
}

export function listProviders(): AiProviderConfigSummary[] {
  return [...providers.values()]
    .sort((a, b) => a.priority - b.priority)
    .map((p) => {
      const hasCred = p.kind === 'ollama' ? true : hasVaultSecret(p.vaultSlot);
      return {
        id: p.id,
        kind: p.kind,
        name: p.name,
        model: p.model,
        baseUrl: p.baseUrl,
        enabled: p.enabled,
        priority: p.priority,
        hasCredential: hasCred,
        status:
          p.kind !== 'ollama' && !hasCred
            ? 'CONFIGURATION_REQUIRED'
            : p.status,
        lastCheckedAt: p.lastCheckedAt,
        lastError: p.lastError,
        requestCount: p.requestCount,
        estimatedTokens: p.estimatedTokens,
      };
    });
}

export function getProviderHistory(): AiRequestHistoryEntry[] {
  return [...requestHistory];
}

export function configureProvider(params: {
  id: string;
  model?: string;
  baseUrl?: string;
  enabled?: boolean;
  priority?: number;
  apiKey?: string;
}): AiProviderConfigSummary {
  const existing = providers.get(params.id);
  if (!existing) {
    throw new Error(`Provedor desconhecido: ${params.id}`);
  }
  if (params.model && params.model.trim()) existing.model = params.model.trim();
  if (params.baseUrl !== undefined) existing.baseUrl = params.baseUrl.trim() || existing.baseUrl;
  if (typeof params.enabled === 'boolean') existing.enabled = params.enabled;
  if (typeof params.priority === 'number' && params.priority >= 1 && params.priority <= 20) {
    existing.priority = params.priority;
  }
  if (typeof params.apiKey === 'string') {
    if (existing.id === 'gemini') {
      throw new Error('A chave GEMINI_API_KEY é gerenciada exclusivamente nas variáveis de ambiente do servidor.');
    }
    if (params.apiKey.trim()) {
      setVaultSecret(existing.vaultSlot, params.apiKey.trim());
      existing.status = 'DISCONNECTED';
      existing.lastError = undefined;
    } else {
      deleteVaultSecret(existing.vaultSlot);
      existing.status = 'CONFIGURATION_REQUIRED';
    }
  }
  return listProviders().find((p) => p.id === existing.id)!;
}

export async function testProviderConnection(id: string): Promise<{
  ok: boolean;
  status: IntegrationStatus;
  latencyMs: number;
  detail: string;
}> {
  const p = providers.get(id);
  if (!p) {
    throw new Error(`Provedor desconhecido: ${id}`);
  }
  const started = Date.now();
  p.lastCheckedAt = new Date().toISOString();

  try {
    if (p.kind === 'gemini') {
      const apiKey = getVaultSecret('gemini');
      if (!apiKey) {
        p.status = 'CONFIGURATION_REQUIRED';
        p.lastError = 'GEMINI_API_KEY não configurada no servidor.';
        return { ok: false, status: p.status, latencyMs: Date.now() - started, detail: p.lastError };
      }
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
      });
      const resp = await ai.models.generateContent({
        model: p.model || 'gemini-4-hydrogen',
        contents: 'Respond strictly with OK.',
      });
      if (resp.text) {
        p.status = 'CONNECTED';
        p.lastError = undefined;
        return {
          ok: true,
          status: 'CONNECTED',
          latencyMs: Date.now() - started,
          detail: `Conectado ao Gemini (${p.model}).`,
        };
      }
      p.status = 'SERVICE_UNAVAILABLE';
      p.lastError = 'Resposta vazia do modelo Gemini.';
      return { ok: false, status: p.status, latencyMs: Date.now() - started, detail: p.lastError };
    }

    if (p.kind === 'ollama') {
      const baseUrl = (getVaultSecret('ollama_url') || p.baseUrl || 'http://127.0.0.1:11434').replace(/\/$/, '');
      const resp = await fetch(`${baseUrl}/api/tags`, { signal: AbortSignal.timeout(3500) });
      if (!resp.ok) {
        p.status = 'SERVICE_UNAVAILABLE';
        p.lastError = `Ollama retornou HTTP ${resp.status}`;
        return { ok: false, status: p.status, latencyMs: Date.now() - started, detail: p.lastError };
      }
      const json = (await resp.json()) as { models?: Array<{ name: string }> };
      p.status = 'CONNECTED';
      p.lastError = undefined;
      return {
        ok: true,
        status: 'CONNECTED',
        latencyMs: Date.now() - started,
        detail: `Ollama ativo em ${baseUrl} (${json.models?.length ?? 0} modelo(s) disponível(is)).`,
      };
    }

    const token = getVaultSecret(p.vaultSlot);
    if (!token) {
      p.status = 'CONFIGURATION_REQUIRED';
      p.lastError = `Credencial ausente para ${p.name}.`;
      return { ok: false, status: p.status, latencyMs: Date.now() - started, detail: p.lastError };
    }

    if (p.kind === 'anthropic') {
      const resp = await fetch(`${(p.baseUrl || 'https://api.anthropic.com/v1').replace(/\/$/, '')}/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': token,
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: p.model,
          max_tokens: 16,
          messages: [{ role: 'user', content: 'Say OK' }],
        }),
        signal: AbortSignal.timeout(8000),
      });
      if (resp.status === 401 || resp.status === 403) {
        p.status = 'AUTHENTICATION_ERROR';
        p.lastError = `Credencial rejeitada (HTTP ${resp.status}).`;
        return { ok: false, status: p.status, latencyMs: Date.now() - started, detail: p.lastError };
      }
      if (!resp.ok) {
        p.status = 'SERVICE_UNAVAILABLE';
        p.lastError = `Erro Anthropic HTTP ${resp.status}`;
        return { ok: false, status: p.status, latencyMs: Date.now() - started, detail: p.lastError };
      }
      p.status = 'CONNECTED';
      p.lastError = undefined;
      return { ok: true, status: 'CONNECTED', latencyMs: Date.now() - started, detail: `Anthropic conectado (${p.model}).` };
    }

    // OpenAI / OpenRouter / Custom OpenAI-compatible
    const base = (p.baseUrl || 'https://api.openai.com/v1').replace(/\/$/, '');
    const resp = await fetch(`${base}/models`, {
      headers: { Authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(6000),
    });
    if (resp.status === 401 || resp.status === 403) {
      p.status = 'AUTHENTICATION_ERROR';
      p.lastError = `Token inválido ou expirado (HTTP ${resp.status}).`;
      return { ok: false, status: p.status, latencyMs: Date.now() - started, detail: p.lastError };
    }
    if (!resp.ok) {
      p.status = 'SERVICE_UNAVAILABLE';
      p.lastError = `Endpoint retornou HTTP ${resp.status}`;
      return { ok: false, status: p.status, latencyMs: Date.now() - started, detail: p.lastError };
    }
    p.status = 'CONNECTED';
    p.lastError = undefined;
    return { ok: true, status: 'CONNECTED', latencyMs: Date.now() - started, detail: `${p.name} conectado (${p.model}).` };
  } catch (err) {
    p.status = 'SERVICE_UNAVAILABLE';
    p.lastError = err instanceof Error ? err.message : String(err);
    return {
      ok: false,
      status: 'SERVICE_UNAVAILABLE',
      latencyMs: Date.now() - started,
      detail: p.lastError,
    };
  }
}

export async function generateTextWithFallback(params: {
  taskType: string;
  systemInstruction: string;
  messages: Array<{ role: 'user' | 'assistant'; content: string }>;
  preferredProviderId?: string;
}): Promise<{ text: string; providerId: string; modelUsed: string; estimatedTokens: number }> {
  const ordered = [...providers.values()]
    .filter((p) => p.enabled)
    .sort((a, b) => {
      if (params.preferredProviderId) {
        if (a.id === params.preferredProviderId) return -1;
        if (b.id === params.preferredProviderId) return 1;
      }
      return a.priority - b.priority;
    });

  const errors: string[] = [];

  for (const p of ordered) {
    const started = Date.now();
    try {
      let text = '';
      if (p.kind === 'gemini') {
        const apiKey = getVaultSecret('gemini');
        if (!apiKey) {
          throw new Error('GEMINI_API_KEY não configurada');
        }
        const ai = new GoogleGenAI({
          apiKey,
          httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
        });
        const resp = await ai.models.generateContent({
          model: p.model || 'gemini-4-hydrogen',
          contents: params.messages.map((m) => ({
            role: m.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: m.content }],
          })),
          config: { systemInstruction: params.systemInstruction },
        });
        text = resp.text || '';
      } else if (p.kind === 'ollama') {
        const base = (getVaultSecret('ollama_url') || p.baseUrl || 'http://127.0.0.1:11434').replace(/\/$/, '');
        const resp = await fetch(`${base}/api/chat`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: p.model,
            stream: false,
            messages: [
              { role: 'system', content: params.systemInstruction },
              ...params.messages,
            ],
          }),
          signal: AbortSignal.timeout(25000),
        });
        if (!resp.ok) throw new Error(`Ollama HTTP ${resp.status}`);
        const json = (await resp.json()) as { message?: { content?: string } };
        text = json.message?.content || '';
      } else if (p.kind === 'anthropic') {
        const token = getVaultSecret(p.vaultSlot);
        if (!token) throw new Error('Anthropic API Key ausente');
        const resp = await fetch(`${(p.baseUrl || 'https://api.anthropic.com/v1').replace(/\/$/, '')}/messages`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': token,
            'anthropic-version': '2023-06-01',
          },
          body: JSON.stringify({
            model: p.model,
            max_tokens: 4096,
            system: params.systemInstruction,
            messages: params.messages,
          }),
          signal: AbortSignal.timeout(30000),
        });
        if (!resp.ok) throw new Error(`Anthropic HTTP ${resp.status}`);
        const json = (await resp.json()) as { content?: Array<{ text?: string }> };
        text = json.content?.map((c) => c.text || '').join('\n') || '';
      } else {
        const token = getVaultSecret(p.vaultSlot);
        if (!token) throw new Error(`Token ausente para ${p.name}`);
        const base = (p.baseUrl || 'https://api.openai.com/v1').replace(/\/$/, '');
        const resp = await fetch(`${base}/chat/completions`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            model: p.model,
            messages: [
              { role: 'system', content: params.systemInstruction },
              ...params.messages,
            ],
          }),
          signal: AbortSignal.timeout(30000),
        });
        if (!resp.ok) throw new Error(`${p.name} HTTP ${resp.status}`);
        const json = (await resp.json()) as {
          choices?: Array<{ message?: { content?: string } }>;
        };
        text = json.choices?.[0]?.message?.content || '';
      }

      if (!text.trim()) {
        throw new Error('Provedor retornou resposta vazia.');
      }

      const estimatedTokens = Math.ceil((params.systemInstruction.length + text.length) / 4);
      p.requestCount += 1;
      p.estimatedTokens += estimatedTokens;
      p.status = 'CONNECTED';
      p.lastError = undefined;
      p.lastCheckedAt = new Date().toISOString();

      recordHistory({
        providerId: p.id,
        providerName: p.name,
        model: p.model,
        taskType: params.taskType,
        success: true,
        latencyMs: Date.now() - started,
        estimatedTokens,
      });

      return {
        text,
        providerId: p.id,
        modelUsed: p.model,
        estimatedTokens,
      };
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      errors.push(`${p.name}: ${msg}`);
      p.lastError = msg;
      p.lastCheckedAt = new Date().toISOString();
      recordHistory({
        providerId: p.id,
        providerName: p.name,
        model: p.model,
        taskType: params.taskType,
        success: false,
        latencyMs: Date.now() - started,
        estimatedTokens: 0,
        error: msg,
      });
    }
  }

  throw new Error(
    errors.length > 0
      ? `Todos os provedores de IA configurados falharam: ${errors.join(' | ')}`
      : 'Nenhum provedor de IA habilitado e configurado.',
  );
}
