import { execFile } from 'child_process';
import { transform } from 'esbuild';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { promisify } from 'util';
import vm from 'vm';
import type { SystemCapabilities } from '../shared/titanTypes.ts';
import { getFirebaseProjectId } from './authMiddleware.ts';

const execFileAsync = promisify(execFile);

let cachedCapabilities: SystemCapabilities | null = null;

async function checkBinary(cmd: string, args: string[]): Promise<{ ok: boolean; output: string | null }> {
  try {
    const { stdout, stderr } = await execFileAsync(cmd, args, { timeout: 2500 });
    return { ok: true, output: (stdout || stderr || '').trim() || 'available' };
  } catch {
    return { ok: false, output: null };
  }
}

export async function getSystemCapabilities(): Promise<SystemCapabilities> {
  if (cachedCapabilities) {
    return {
      ...cachedCapabilities,
      geminiConfigured: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 0),
      firebaseConfigured: Boolean(getFirebaseProjectId()),
    };
  }

  const [py, java, gradle, sdkmanager, git] = await Promise.all([
    checkBinary('python3', ['--version']),
    checkBinary('java', ['-version']),
    checkBinary('gradle', ['-v']),
    checkBinary('sdkmanager', ['--version']),
    checkBinary('git', ['--version']),
  ]);

  cachedCapabilities = {
    nodeVersion: process.version,
    pythonAvailable: py.ok,
    pythonVersion: py.output,
    gitAvailable: git.ok,
    gitVersion: git.output,
    geminiConfigured: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 0),
    androidSdkAvailable: sdkmanager.ok,
    gradleAvailable: gradle.ok,
    javaAvailable: java.ok,
    firebaseConfigured: Boolean(getFirebaseProjectId()),
    modelName: 'gemini-4-hydrogen',
  };

  return cachedCapabilities;
}

export interface SandboxExecutionResult {
  executed: boolean;
  syntaxValid: boolean;
  runtime: string;
  exitCode: number | null;
  stdout: string;
  stderr: string;
  durationMs: number;
  limitationReason?: string;
}

export async function runIsolatedCode(params: {
  language: string;
  code: string;
  stdin?: string;
  syntaxOnly?: boolean;
}): Promise<SandboxExecutionResult> {
  const lang = params.language.toLowerCase();
  const started = Date.now();

  if (lang === 'python' || lang === 'py') {
    const caps = await getSystemCapabilities();
    if (!caps.pythonAvailable) {
      return {
        executed: false,
        syntaxValid: false,
        runtime: 'Python 3',
        exitCode: null,
        stdout: '',
        stderr: '',
        durationMs: Date.now() - started,
        limitationReason: 'Runtime Python 3 não disponível neste container.',
      };
    }

    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'titan-py-'));
    const scriptPath = path.join(tempDir, 'main.py');
    try {
      fs.writeFileSync(scriptPath, params.code, 'utf-8');

      // Step 1: Real syntax compilation via py_compile
      try {
        await execFileAsync('python3', ['-m', 'py_compile', scriptPath], { timeout: 3000 });
      } catch (syntaxErr: unknown) {
        const e = syntaxErr as { stderr?: string; message?: string };
        return {
          executed: false,
          syntaxValid: false,
          runtime: caps.pythonVersion || 'Python 3',
          exitCode: 1,
          stdout: '',
          stderr: (e.stderr || e.message || 'Erro de sintaxe Python').slice(0, 8000),
          durationMs: Date.now() - started,
        };
      }

      if (params.syntaxOnly) {
        return {
          executed: true,
          syntaxValid: true,
          runtime: caps.pythonVersion || 'Python 3',
          exitCode: 0,
          stdout: 'py_compile aprovado sem erros de sintaxe.',
          stderr: '',
          durationMs: Date.now() - started,
        };
      }

      // Step 2: Isolated execution with -I flag and strict timeout
      return await new Promise<SandboxExecutionResult>((resolve) => {
        const child = execFile(
          'python3',
          ['-I', scriptPath],
          { cwd: tempDir, timeout: 4000, maxBuffer: 64 * 1024 },
          (err, stdout, stderr) => {
            const durationMs = Date.now() - started;
            if (err) {
              const code = typeof (err as { code?: unknown }).code === 'number' ? (err as { code: number }).code : 1;
              resolve({
                executed: true,
                syntaxValid: true,
                runtime: caps.pythonVersion || 'Python 3',
                exitCode: code,
                stdout: (stdout || '').slice(0, 16000),
                stderr: (stderr || err.message || '').slice(0, 16000),
                durationMs,
              });
            } else {
              resolve({
                executed: true,
                syntaxValid: true,
                runtime: caps.pythonVersion || 'Python 3',
                exitCode: 0,
                stdout: (stdout || '').slice(0, 16000),
                stderr: (stderr || '').slice(0, 16000),
                durationMs,
              });
            }
          },
        );
        if (params.stdin && child.stdin) {
          child.stdin.write(params.stdin);
          child.stdin.end();
        } else if (child.stdin) {
          child.stdin.end();
        }
      });
    } finally {
      fs.rmSync(tempDir, { recursive: true, force: true });
    }
  }

  if (lang === 'javascript' || lang === 'js' || lang === 'typescript' || lang === 'ts') {
    let jsCode = params.code;
    try {
      const transformed = await transform(params.code, {
        loader: lang === 'typescript' || lang === 'ts' ? 'ts' : 'js',
        format: 'cjs',
        target: 'es2022',
      });
      jsCode = transformed.code;
    } catch (err) {
      return {
        executed: false,
        syntaxValid: false,
        runtime: `Node.js ${process.version} (esbuild)`,
        exitCode: 1,
        stdout: '',
        stderr: err instanceof Error ? err.message : String(err),
        durationMs: Date.now() - started,
      };
    }

    if (params.syntaxOnly) {
      return {
        executed: true,
        syntaxValid: true,
        runtime: `Node.js ${process.version} (esbuild)`,
        exitCode: 0,
        stdout: 'Transpilação esbuild aprovada sem erros de sintaxe.',
        stderr: '',
        durationMs: Date.now() - started,
      };
    }

    const logs: string[] = [];
    const errors: string[] = [];
    const sandboxConsole = {
      log: (...args: unknown[]) => logs.push(args.map(formatArg).join(' ')),
      info: (...args: unknown[]) => logs.push(args.map(formatArg).join(' ')),
      warn: (...args: unknown[]) => errors.push(args.map(formatArg).join(' ')),
      error: (...args: unknown[]) => errors.push(args.map(formatArg).join(' ')),
    };
    const context = vm.createContext({
      console: sandboxConsole,
      Math,
      Date,
      JSON,
      Array,
      Object,
      String,
      Number,
      Boolean,
      Map,
      Set,
      RegExp,
      Error,
      Promise,
      exports: {},
      module: { exports: {} },
    });

    try {
      vm.runInContext(jsCode, context, { timeout: 2000 });
      return {
        executed: true,
        syntaxValid: true,
        runtime: `Node.js VM (${process.version})`,
        exitCode: 0,
        stdout: logs.join('\n').slice(0, 16000),
        stderr: errors.join('\n').slice(0, 16000),
        durationMs: Date.now() - started,
      };
    } catch (err) {
      return {
        executed: true,
        syntaxValid: true,
        runtime: `Node.js VM (${process.version})`,
        exitCode: 1,
        stdout: logs.join('\n').slice(0, 16000),
        stderr: (err instanceof Error ? err.stack || err.message : String(err)).slice(0, 16000),
        durationMs: Date.now() - started,
      };
    }
  }

  return {
    executed: false,
    syntaxValid: true,
    runtime: params.language,
    exitCode: null,
    stdout: '',
    stderr: '',
    durationMs: Date.now() - started,
    limitationReason: `Execução direta no container disponível para Python, JavaScript e TypeScript. Para ${params.language}, a validação estática e estrutural foi executada; execute o código no runtime de destino (${params.language === 'Luau' ? 'Roblox Studio' : params.language === 'Kotlin' ? 'Android Studio / Gradle' : params.language}).`,
  };
}

function formatArg(val: unknown): string {
  if (typeof val === 'string') return val;
  try {
    return JSON.stringify(val);
  } catch {
    return String(val);
  }
}
