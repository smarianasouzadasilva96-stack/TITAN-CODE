# TITAN CODE — Android APK

Este pacote prepara o projeto web para ser empacotado como aplicativo Android usando Capacitor 7. O nome do aplicativo está definido como **TITAN CODE** e o identificador Android é `com.titancode.app`.

## Importante: o que este ZIP contém

- Código original React/Vite e os recursos gráficos existentes do TITAN CODE.
- Configuração do Capacitor e dependência da plataforma Android.
- Scripts para criar e sincronizar o projeto Android.
- Instruções para conectar o app ao backend HTTPS.

Este ZIP **não é um APK compilado** e não contém ainda a pasta `android/`. A pasta é criada pelo Capacitor durante `npx cap add android`. O APKTool M não compila diretamente um projeto React/TypeScript: ele trabalha com APKs já compilados (descompilar/editar/recompilar recursos). Para gerar o APK é necessário Android Studio/SDK e Gradle, normalmente num computador.

## 1. Backend completo (necessário para IA e recursos de servidor)

O backend Express precisa ficar hospedado num serviço Node.js com HTTPS. Não coloque chaves de IA, segredos ou credenciais privadas dentro do APK nem em variáveis `VITE_*`.

1. Publique o projeto num host que mantenha o processo Node.js ativo.
2. Configure no host as variáveis privadas exigidas pelo backend (por exemplo, credenciais do provedor de IA e `TITAN_VAULT_SECRET`).
3. Configure build/start conforme o host: `npm install`, `npm run build` e `npm start`.
4. Teste o endpoint de saúde `https://SEU-DOMINIO/api/health`.

## 2. Configurar o endereço do backend

Crie `.env.production` na raiz do projeto:

```env
VITE_API_BASE_URL=https://SEU-DOMINIO
```

Substitua pelo domínio HTTPS real do seu backend. Não use `localhost` no APK instalado no celular.

## 3. Criar e sincronizar o projeto Android

Com Node.js e Android Studio/SDK instalados, na pasta do projeto execute:

```bash
npm install
npm run build
npm run android:add
npx cap sync android
npx cap open android
```

Se a pasta `android/` já existir, não execute `android:add` novamente; use apenas `npm run android:sync`.

No Android Studio, aguarde o Gradle terminar a sincronização. Para gerar APK assinado: **Build > Generate Signed Bundle / APK > APK**. Crie e guarde o keystore e sua senha em local seguro; sem eles pode ser impossível atualizar o app assinado com a mesma identidade.

## 4. APKTool M

Depois que um APK tiver sido gerado, o APKTool M pode ser usado para tarefas de inspeção/edição compatíveis e recompilação/assinatura. Ele não substitui a etapa de build do projeto React + Capacitor.

## 5. Verificações antes de distribuir

- Testar login e autenticação Google em aparelho real.
- Conferir regras do Firestore e domínios autorizados no Firebase.
- Testar todas as chamadas ao backend HTTPS.
- Não distribuir APK com chaves privadas ou `.env` contendo segredos.
- Guardar backup do keystore e não compartilhar sua senha.
